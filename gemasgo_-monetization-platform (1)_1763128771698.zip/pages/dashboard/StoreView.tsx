import React, { useState } from 'react';
import { User, AppSettings, NotificationType, PurchaseRequest, DiamondRedemption } from '../../types';
import { CoinIcon, HeartIcon, DiamondIcon } from '../../components/icons';
import Spinner from '../../components/Spinner';
import ConfirmationModal from '../../components/ConfirmationModal';

interface StoreViewProps {
    user: User;
    appSettings: AppSettings;
    onNewPurchaseRequest: (requestData: Omit<PurchaseRequest, 'id' | 'userId'|'userName'|'status'|'type'>, proofKey: string) => Promise<boolean>;
    onNewDiamondRedemption: (requestData: Omit<DiamondRedemption, 'id' | 'userId'|'userName'|'status'|'type'>) => void;
    onUpdateUser: (userId: string, updates: Partial<User>) => Promise<User | undefined>;
    addNotification: (message: string, type: NotificationType) => void;
}


const fileToKey = async (file: File): Promise<string> => {
    const buffer = await file.arrayBuffer();
    const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
};

const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
  });
};

type StoreSubView = 'redeem-diamonds' | 'buy-lives' | 'buy-gemasgo';

const StoreView: React.FC<StoreViewProps> = ({ user, appSettings, onNewPurchaseRequest, onNewDiamondRedemption, onUpdateUser, addNotification }) => {
    const [subView, setSubView] = useState<StoreSubView>('redeem-diamonds');
    const [isLoading, setIsLoading] = useState<string | null>(null);

    // State for Redeem Diamonds
    const [ffUserId, setFfUserId] = useState('');
    
    // State for Buy Lives
    const [livesAmount, setLivesAmount] = useState(1);
    const [isLivesConfirmOpen, setIsLivesConfirmOpen] = useState(false);

    // State for Buy GemasGo
    const [gemasGoAmount, setGemasGoAmount] = useState(10);
    const [paymentProof, setPaymentProof] = useState<File | null>(null);
    const [showPaymentModal, setShowPaymentModal] = useState(false);
    const [isGemasConfirmOpen, setIsGemasConfirmOpen] = useState(false);


    const handleRedeemDiamonds = async (amount: 100 | 465, cost: number) => {
        if (!ffUserId.trim()) {
            addNotification('Por favor, introduce tu ID de Free Fire.', 'error');
            return;
        }
        setIsLoading(`redeem-${amount}`);
        await onNewDiamondRedemption({ diamondAmount: amount, gemasGoCost: cost, ffUserId });
        setFfUserId('');
        setIsLoading(null);
    };

    const handleBuyLives = () => {
        const totalCost = livesAmount * appSettings.livesCost;
        if (user.gemasGo < totalCost) {
            addNotification('GemasGo insuficientes.', 'error');
            return;
        }
        setIsLivesConfirmOpen(true);
    };
    
    const confirmBuyLives = async () => {
        setIsLoading('lives');
        try {
            const totalCost = livesAmount * appSettings.livesCost;
            await onUpdateUser(user.id, {
                lives: user.lives + livesAmount,
                gemasGo: user.gemasGo - totalCost
            });
            addNotification(`${livesAmount} vida(s) comprada(s)!`, 'success');
        } catch (error) {
            // Error notification will be shown by the parent component
        } finally {
            setIsLivesConfirmOpen(false);
            setIsLoading(null);
        }
    }

    const handleBuyGemasGo = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!paymentProof) {
            addNotification('Por favor, sube un comprobante de pago.', 'error');
            return;
        }
        
        setIsLoading('gemas');
        try {
            const proofKey = await fileToKey(paymentProof);
            const proofBase64 = await fileToBase64(paymentProof);
            const success = await onNewPurchaseRequest({
                amountGemas: gemasGoAmount,
                amountUSD: gemasGoAmount, // 1:1 Rate
                paymentProofUrl: proofBase64,
            }, proofKey);

            if (success) {
                setShowPaymentModal(false);
                setPaymentProof(null);
            }
        } finally {
            setIsLoading(null);
        }
    };

    const proceedToGemasPurchase = () => {
        setIsGemasConfirmOpen(false);
        setShowPaymentModal(true);
    };

    const handleCopyAddress = () => {
        navigator.clipboard.writeText(appSettings.cryptoAddress).then(() => {
            addNotification('Dirección copiada al portapapeles!', 'success');
        }, () => {
            addNotification('No se pudo copiar la dirección.', 'error');
        });
    };

    const SubNavButton: React.FC<{ view: StoreSubView, icon: React.ReactElement<{ className?: string }>, label: string }> = ({ view, icon, label }) => (
        <button
            onClick={() => setSubView(view)}
            className={`flex-1 flex items-center justify-center space-x-1.5 p-2 rounded-t-lg border-b-2 transition-colors ${
                subView === view
                ? 'border-blue-500 text-blue-400'
                : 'border-transparent text-gray-500 hover:text-gray-200'
            }`}
        >
            {React.cloneElement(icon, { className: "w-4 h-4" })}
            <span className="font-bold text-xs hidden sm:inline">{label}</span>
        </button>
    );

    return (
        <div className="animate-fade-in">
            <h2 className="text-xl font-bold mb-3 text-green-400">Tienda</h2>
            <div className="bg-gray-800/70 backdrop-blur-sm rounded-xl shadow-lg">
                <div className="flex border-b border-gray-700">
                    <SubNavButton view="redeem-diamonds" icon={<DiamondIcon />} label="Canjear Diamantes" />
                    <SubNavButton view="buy-lives" icon={<HeartIcon />} label="Comprar Vidas" />
                    <SubNavButton view="buy-gemasgo" icon={<CoinIcon />} label="Comprar GemasGo" />
                </div>

                <div className="p-3 sm:p-4">
                    {subView === 'redeem-diamonds' && (
                        <div className="space-y-3">
                            <h3 className="text-lg font-bold text-center mb-1">Canjear Diamantes de Free Fire</h3>
                            <input type="text" value={ffUserId} onChange={e => setFfUserId(e.target.value)} placeholder="Introduce tu ID de Jugador de Free Fire" className="w-full p-2 text-xs bg-gray-700 rounded-md border border-gray-600" />
                            {[
                                { amount: 100, cost: 1.03 },
                                { amount: 465, cost: 4.67 }
                            ].map(pack => (
                                <div key={pack.amount} className="flex flex-col sm:flex-row items-center justify-between p-2 bg-gray-700/50 rounded-lg text-xs">
                                    <p className="font-semibold">{pack.amount} Diamantes por {pack.cost.toFixed(2)} GemasGo</p>
                                    <button onClick={() => handleRedeemDiamonds(pack.amount as 100 | 465, pack.cost)} disabled={user.gemasGo < pack.cost || !ffUserId.trim() || !!isLoading} className="mt-2 sm:mt-0 w-full sm:w-20 text-[11px] bg-blue-500 hover:bg-blue-600 text-white font-bold py-1.5 px-2 rounded-lg disabled:bg-gray-400">
                                        {isLoading === `redeem-${pack.amount}` ? <Spinner /> : 'Canjear'}
                                    </button>
                                </div>
                            ))}
                        </div>
                    )}
                    {subView === 'buy-lives' && (
                        <div className="text-center">
                            <h3 className="text-lg font-bold mb-1">Comprar Vidas</h3>
                            <p className="mb-2 text-gray-400 text-xs">Cada vida cuesta {appSettings.livesCost.toFixed(2)} GemasGo.</p>
                            <div className="flex items-center justify-center space-x-2 mb-3">
                                <button onClick={() => setLivesAmount(p => Math.max(1, p - 1))} className="w-7 h-7 rounded-full bg-gray-600 font-bold text-base">-</button>
                                <span className="text-xl font-bold w-10 text-center">{livesAmount}</span>
                                <button onClick={() => setLivesAmount(p => p + 1)} className="w-7 h-7 rounded-full bg-gray-600 font-bold text-base">+</button>
                            </div>
                            <button onClick={handleBuyLives} className="w-full max-w-xs mx-auto bg-red-500 hover:bg-red-600 text-white font-bold py-1.5 px-4 rounded-lg text-xs">Comprar por {(livesAmount * appSettings.livesCost).toFixed(2)} GemasGo</button>
                        </div>
                    )}
                    {subView === 'buy-gemasgo' && (
                        <div className="text-center">
                            <h3 className="text-lg font-bold mb-1">Comprar GemasGo con Crypto ({appSettings.cryptoCurrency})</h3>
                            <p className="mb-3 text-gray-400 text-xs">1 GemasGo = 1 {appSettings.cryptoCurrency}. Envía el pago a nuestra dirección y sube el comprobante.</p>
                             <div className="p-2 rounded-lg bg-yellow-900/40 border border-yellow-500/30 mb-3">
                                <p className="font-bold text-yellow-200 text-xs">¡Advertencia Importante!</p>
                                <p className="text-[10px] text-yellow-300">
                                    No proporcionar un comprobante de pago válido puede resultar en el rechazo de tu compra sin reembolso.
                                </p>
                            </div>
                            <button onClick={() => setIsGemasConfirmOpen(true)} className="w-full max-w-xs mx-auto bg-green-500 hover:bg-green-600 text-white font-bold py-1.5 px-4 rounded-lg text-xs">Iniciar Compra</button>
                            {showPaymentModal && (
                                <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center" onClick={() => setShowPaymentModal(false)}>
                                    <div className="bg-gray-800/80 backdrop-blur-sm rounded-xl p-6 max-w-lg w-full" onClick={e => e.stopPropagation()}>
                                        <h4 className="text-lg font-bold mb-3">Proceso de Pago</h4>
                                        <form onSubmit={handleBuyGemasGo} className="space-y-3 text-sm">
                                            <div>
                                                <label className="block text-xs font-medium text-left">Cantidad de GemasGo a comprar (1 {appSettings.cryptoCurrency} = 1 GemasGo)</label>
                                                <input type="number" min="1" value={gemasGoAmount} onChange={e => setGemasGoAmount(parseInt(e.target.value, 10) || 1)} className="w-full p-2 bg-gray-700 rounded-md mt-1 text-xs" />
                                            </div>
                                            <p className="text-xs text-left">Por favor, envía <strong className="text-green-500">{gemasGoAmount} {appSettings.cryptoCurrency}</strong> a la siguiente dirección:</p>
                                            <div className="flex items-center space-x-2 p-2 bg-gray-700 rounded-md">
                                                <span className="font-mono text-xs break-all flex-grow">{appSettings.cryptoAddress}</span>
                                                <button type="button" onClick={handleCopyAddress} title="Copy Address" className="bg-gray-600 p-2 rounded-md hover:bg-gray-500">
                                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
                                                </button>
                                            </div>
                                            <div>
                                                <label className="block text-xs font-medium text-left">Sube el Comprobante de Pago (Screenshot)</label>
                                                <input type="file" accept="image/*" onChange={e => setPaymentProof(e.target.files ? e.target.files[0] : null)} className="w-full text-xs mt-1 file:mr-4 file:py-1.5 file:px-3 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-blue-900/50 file:text-blue-300 hover:file:bg-blue-900" />
                                            </div>
                                            <button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 rounded-lg text-sm" disabled={isLoading === 'gemas'}>
                                                {isLoading === 'gemas' ? <Spinner /> : 'Confirmar y Enviar Comprobante'}
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            )}
                        </div>
                    )}
                </div>
            </div>
            
            <ConfirmationModal
              isOpen={isLivesConfirmOpen}
              onClose={() => setIsLivesConfirmOpen(false)}
              onConfirm={confirmBuyLives}
              title="Confirmar Compra de Vidas"
              isConfirming={isLoading === 'lives'}
              confirmText="Confirmar"
            >
              <p className="text-gray-300">
                ¿Estás seguro de que quieres comprar <strong>{livesAmount}</strong> vida(s) por <strong className="text-yellow-500">{(livesAmount * appSettings.livesCost).toFixed(2)} GemasGo</strong>?
              </p>
            </ConfirmationModal>

            <ConfirmationModal
              isOpen={isGemasConfirmOpen}
              onClose={() => setIsGemasConfirmOpen(false)}
              onConfirm={proceedToGemasPurchase}
              title="Confirmar Compra de GemasGo"
              confirmText="Continuar"
            >
              <p className="text-gray-300">
                Se te dirigirá al proceso de pago para comprar GemasGo con {appSettings.cryptoCurrency}. ¿Quieres continuar?
              </p>
            </ConfirmationModal>
        </div>
    );
};

export default StoreView;
