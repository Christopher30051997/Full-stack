


import React, { useState, useRef, useEffect } from 'react';
import { GeminiToolView } from '../../types';
import { getGroundedAnswer, getFastAnswer } from '../../services/geminiService';
import Spinner from '../../components/Spinner';

interface GroundedResult {
    text: string;
    sources: any[];
}
interface SearchTurn {
    id: number;
    prompt: string;
    response: GroundedResult;
}

const GroundedSearch: React.FC = () => {
    const [prompt, setPrompt] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [history, setHistory] = useState<SearchTurn[]>([]);
    const [error, setError] = useState<string | null>(null);
    const historyContainerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (historyContainerRef.current) {
            historyContainerRef.current.scrollTop = historyContainerRef.current.scrollHeight;
        }
    }, [history]);

    const handleSearch = async () => {
        if (!prompt || isLoading) return;
        const sentPrompt = prompt;
        setPrompt('');
        setIsLoading(true);
        setError(null);
        try {
            const response = await getGroundedAnswer(sentPrompt);
            setHistory(prev => [...prev, { id: Date.now(), prompt: sentPrompt, response }]);
        } catch (err) {
            setError(err instanceof Error ? err.message : "An unknown error occurred.");
            setPrompt(sentPrompt);
        } finally {
            setIsLoading(false);
        }
    }

    return (
         <div className="animate-fade-in">
            <h3 className="text-lg font-bold mb-2 text-blue-400">Grounded Search</h3>
            <div className="bg-gray-800/70 backdrop-blur-sm p-3 rounded-xl shadow-lg flex flex-col max-h-[50vh]">
                <div ref={historyContainerRef} className="flex-grow overflow-y-auto pr-2 space-y-4 scrollbar-hide">
                    {history.length === 0 && !isLoading && (
                        <div className="flex items-center justify-center h-full text-gray-500">
                            Pregunta sobre eventos recientes o noticias...
                        </div>
                    )}
                    {history.map(turn => (
                        <div key={turn.id}>
                            <p className="font-semibold text-gray-400 text-xs mb-1">Tú:</p>
                            <div className="bg-gray-700/50 p-2 rounded-lg text-xs mb-2 whitespace-pre-wrap">{turn.prompt}</div>
                            
                            <p className="font-semibold text-blue-400 text-xs mb-1">Grounded Search:</p>
                            <div className="bg-gray-900/50 p-2 rounded-lg border border-gray-700">
                               <p className="whitespace-pre-wrap text-gray-200 text-xs">{turn.response.text}</p>
                               {turn.response.sources.length > 0 && (
                                    <div className="mt-3 pt-3 border-t border-gray-700">
                                        <h4 className="font-semibold text-xs text-gray-400 mb-1">Fuentes:</h4>
                                        <ul className="list-disc list-inside text-xs space-y-1">
                                            {turn.response.sources.map((source, index) => (
                                                <li key={index}>
                                                    <a href={source.web?.uri} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">{source.web?.title}</a>
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                               )}
                            </div>
                        </div>
                    ))}
                    {isLoading && <div className="flex justify-center"><Spinner /></div>}
                    {error && <p className="text-red-500 mt-3 font-semibold bg-red-900/30 p-2 rounded-md text-sm">{error}</p>}
                </div>
                <div className="flex space-x-2 pt-3 border-t border-gray-700/50 mt-2">
                   <input type="text" placeholder="Pregunta sobre eventos recientes o noticias..." value={prompt} onChange={e => setPrompt(e.target.value)} onKeyPress={e => e.key === 'Enter' && handleSearch()} className="flex-grow p-1.5 bg-gray-700 text-gray-200 rounded-md border border-gray-600 text-xs" />
                   <button onClick={handleSearch} disabled={isLoading || !prompt} className="bg-blue-500 hover:bg-blue-600 text-white font-bold px-3 py-1.5 rounded-lg transition disabled:bg-gray-500 text-xs">
                        {isLoading ? <Spinner size="w-4 h-4" /> : 'Buscar'}
                   </button>
                </div>
            </div>
        </div>
    )
}

interface ChatTurn {
    id: number;
    prompt: string;
    response: string;
}

const FastChat: React.FC = () => {
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [history, setHistory] = useState<ChatTurn[]>([]);
    const [error, setError] = useState<string|null>(null);
    const historyContainerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (historyContainerRef.current) {
            historyContainerRef.current.scrollTop = historyContainerRef.current.scrollHeight;
        }
    }, [history]);

    const handleSend = async () => {
        if (!input || isLoading) return;
        const sentInput = input;
        setInput('');
        setError(null);
        setIsLoading(true);

        try {
            const response = await getFastAnswer(`You are a helpful assistant for the GemasGo platform. Keep your answers brief and friendly. Question: ${sentInput}`);
            setHistory(prev => [...prev, { id: Date.now(), prompt: sentInput, response }]);
        } catch (err) {
             const errorMessage = err instanceof Error ? err.message : "Sorry, I couldn't get an answer.";
             setError(errorMessage);
             setInput(sentInput);
        } finally {
            setIsLoading(false);
        }
    }

    return (
        <div className="animate-fade-in">
            <h3 className="text-lg font-bold mb-2 text-blue-400">Quick Assistant</h3>
            <div className="bg-gray-800/70 backdrop-blur-sm p-3 rounded-xl shadow-lg flex flex-col max-h-[50vh]">
                 <div ref={historyContainerRef} className="flex-grow overflow-y-auto pr-2 space-y-4 scrollbar-hide">
                    {history.length === 0 && !isLoading && (
                        <div className="flex items-center justify-center h-full text-gray-500">
                            ¿Cómo puedo ayudarte?
                        </div>
                    )}
                    {history.map(turn => (
                         <div key={turn.id}>
                            <p className="font-semibold text-gray-400 text-xs mb-1">Tú:</p>
                            <div className="bg-gray-700/50 p-2 rounded-lg text-xs mb-2 whitespace-pre-wrap">{turn.prompt}</div>
                            
                            <p className="font-semibold text-blue-400 text-xs mb-1">Asistente:</p>
                            <div className="bg-gray-900/50 p-2 rounded-lg border border-gray-700">
                                <p className="whitespace-pre-wrap text-gray-200 text-xs">{turn.response}</p>
                            </div>
                        </div>
                    ))}
                    {isLoading && <div className="flex justify-center"><Spinner /></div>}
                    {error && <p className="text-red-500 mt-3 font-semibold bg-red-900/30 p-2 rounded-md text-sm">{error}</p>}
                </div>
                <div className="flex space-x-2 pt-3 border-t border-gray-700/50 mt-2">
                   <input type="text" placeholder="¿Cómo gano GemasGo?" value={input} onChange={e => setInput(e.target.value)} onKeyPress={e => e.key === 'Enter' && handleSend()} className="flex-grow p-1.5 bg-gray-700 text-gray-200 rounded-md border border-gray-600 text-xs" />
                   <button onClick={handleSend} disabled={isLoading || !input} className="bg-blue-500 hover:bg-blue-600 text-white font-bold px-3 py-1.5 rounded-lg transition disabled:bg-gray-500 text-xs">
                        {isLoading ? <Spinner size="w-4 h-4" /> : 'Enviar'}
                   </button>
                </div>
            </div>
        </div>
    );
}

const GeminiToolsView: React.FC = () => {
    const [activeTool, setActiveTool] = useState<GeminiToolView>('grounded-search');

    const ToolButton: React.FC<{ tool: GeminiToolView; label: string }> = ({ tool, label }) => (
        <button
            onClick={() => setActiveTool(tool)}
            className={`px-2 py-1 font-semibold transition-colors text-xs rounded-t-lg ${
                activeTool === tool ? 'text-blue-400 border-b-2 border-blue-400' : 'text-gray-400 hover:text-gray-200'
            }`}
        >
            {label}
        </button>
    );

     const renderTool = () => {
        switch(activeTool) {
            case 'grounded-search': return <GroundedSearch />;
            case 'fast-chat': return <FastChat />;
            default: return <GroundedSearch />;
        }
    };
    
    return (
        <div className="animate-fade-in">
            <h2 className="text-xl font-bold mb-3 text-blue-400">Gemini AI Tools</h2>
            <div className="border-b border-gray-700 mb-4">
                <nav className="-mb-px flex space-x-1">
                    <ToolButton tool="grounded-search" label="Grounded Search" />
                    <ToolButton tool="fast-chat" label="Quick Assistant" />
                </nav>
            </div>
            {renderTool()}
        </div>
    );
};

export default GeminiToolsView;