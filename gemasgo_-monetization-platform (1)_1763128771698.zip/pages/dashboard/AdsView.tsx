import React from 'react';
import { Promotion, RequestStatus } from '../../types';

interface AdsViewProps {
    promotions: Promotion[];
}

const AdsView: React.FC<AdsViewProps> = ({ promotions }) => {
    // For a user, this view might be about watching ads or seeing community promotions
    // For this demo, let's just display a message.
    return (
        <div className="animate-fade-in">
            <h2 className="text-xl font-bold mb-3 text-cyan-400">Ver Anuncios</h2>
            <div className="bg-gray-800/70 backdrop-blur-sm p-4 rounded-xl shadow-lg text-center">
                <h3 className="text-lg font-semibold text-gray-100 mb-2">Gana GemasGo Viendo Anuncios</h3>
                <p className="text-gray-400 mb-4 text-xs">
                    Esta función estará disponible próximamente. ¡Vuelve pronto para ganar más recompensas!
                </p>
                <button
                    disabled
                    className="bg-cyan-500 text-white font-bold py-1.5 px-4 rounded-lg transition opacity-50 cursor-not-allowed text-xs"
                >
                    Ver Anuncio
                </button>
            </div>

            <div className="mt-6">
                <h3 className="text-lg font-bold mb-2 text-gray-300">Promociones de la Comunidad</h3>
                {promotions.filter(p => p.status === RequestStatus.APPROVED).length > 0 ? (
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
                       {promotions.filter(p => p.status === RequestStatus.APPROVED).map(promo => (
                           <div key={promo.id} className="bg-gray-800/70 backdrop-blur-sm p-3 rounded-xl shadow-lg flex flex-col justify-between text-xs">
                               <div>
                                   <p className="text-gray-200 mb-1">
                                       ¡El usuario <strong>{promo.userName}</strong> está promocionando!
                                   </p>
                                   <p className="text-[11px] text-gray-400 mb-1.5">
                                       Interactúa con la publicación para ganar una recompensa.
                                   </p>
                                   {/* FIX: Accessing properties from the nested 'details' object */}
                                   <div className="text-[11px] text-gray-300">
                                       Objetivos: {promo.details.views > 0 && `${promo.details.views} vistas `} {promo.details.likes > 0 && `${promo.details.likes} me gusta `} {promo.details.comments > 0 && `${promo.details.comments} comentarios`}
                                   </div>
                               </div>
                               <a 
                                 href={promo.details.postUrl} 
                                 target="_blank" 
                                 rel="noopener noreferrer"
                                 className="mt-2 w-full text-center bg-blue-500 hover:bg-blue-600 text-white font-bold py-1 px-2 rounded-lg transition text-[11px]"
                               >
                                  Ver y Participar
                               </a>
                           </div>
                       ))}
                    </div>
                ) : (
                    <div className="text-center p-6 bg-gray-800/70 backdrop-blur-sm rounded-xl shadow-lg">
                        <p className="text-gray-400 text-sm">No hay promociones activas en este momento.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default AdsView;