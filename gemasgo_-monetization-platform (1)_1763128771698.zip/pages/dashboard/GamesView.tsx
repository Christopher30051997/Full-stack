import React, { useState, useMemo, useEffect } from 'react';
import { Game, User, AppSettings } from '../../types';
import { StarIcon, PlayIcon, HeartIcon } from '../../components/icons';
import Spinner from '../../components/Spinner';

interface GamesViewProps {
    games: Game[];
    user: User;
    onUpdateUser: (userId: string, updates: Partial<User>) => Promise<User | undefined>;
    onToggleFavoriteGame: (gameId: string) => void;
    appSettings: AppSettings;
}

const GameCard: React.FC<{
    game: Game;
    user: User;
    onPlay: (gameId: string) => void;
    onToggleFavorite: (gameId: string) => void;
    isPlaying: boolean;
}> = ({ game, user, onPlay, onToggleFavorite, isPlaying }) => {
    const isFavorite = user.favoriteGameIds.includes(game.id);
    const hasProgress = game.supportsSave && user.gameProgress?.[game.id];
    const progress = hasProgress ? user.gameProgress[game.id] : null;

    return (
        <div className="flex flex-col">
            <div className="relative group aspect-[3/4] w-full rounded-xl overflow-hidden shadow-lg transform transition-all duration-300 ease-in-out hover:scale-105 hover:shadow-2xl hover:shadow-purple-500/40">
                <img src={game.imageUrl} alt={game.name} className="w-full h-full object-cover" />
                
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <button
                        onClick={() => onPlay(game.id)}
                        disabled={user.lives <= 0 || isPlaying}
                        className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center text-white transition-transform transform hover:scale-110 disabled:opacity-50 disabled:cursor-not-allowed"
                        aria-label={`Play ${game.name}`}
                    >
                        {isPlaying ? <Spinner size="w-8 h-8"/> : <PlayIcon className="w-8 h-8" />}
                    </button>
                </div>

                <button
                    onClick={() => onToggleFavorite(game.id)}
                    className={`absolute top-2 right-2 p-1.5 rounded-full transition-colors duration-200 ${isFavorite ? 'text-yellow-400 bg-black/60' : 'text-white/70 bg-black/40 hover:text-yellow-400'}`}
                    aria-label={isFavorite ? 'Remove from favorites' : 'Add to favorites'}
                >
                    <StarIcon className="w-5 h-5" isFilled={isFavorite} />
                </button>
            </div>
            <div className="mt-2 text-left">
                <h3 className="text-sm font-bold text-gray-100 truncate">{game.name}</h3>
                <div className="flex justify-between items-center">
                    <p className="text-xs text-gray-400">{game.genre}</p>
                     {hasProgress && <p className="text-xs text-green-400 font-semibold">Level {progress.level}</p>}
                </div>
            </div>
        </div>
    );
};

const GAMES_PER_PAGE = 15;

const GamesView: React.FC<GamesViewProps> = ({ games, user, onUpdateUser, onToggleFavoriteGame, appSettings }) => {
    const [playingGameId, setPlayingGameId] = useState<string | null>(null);
    const [visibleCount, setVisibleCount] = useState(GAMES_PER_PAGE);
    const [isLoadingMore, setIsLoadingMore] = useState(false);
    const [timeLeft, setTimeLeft] = useState('00:00');

    useEffect(() => {
        if (!appSettings.lifeRegenEnabled || user.lives >= 5) {
            setTimeLeft('Full');
            return;
        }

        const regenIntervalMs = appSettings.lifeRegenMinutes * 60 * 1000;

        const calculateTime = () => {
            const now = Date.now();
            const lastRegen = user.lastLifeRegenTimestamp || now;
            
            const elapsedMs = now - lastRegen;
            const remainingMs = Math.max(0, regenIntervalMs - elapsedMs);
            
            if(remainingMs === 0) {
                 // The parent will refetch data and update lives soon.
                 // We can anticipate this to avoid showing 00:00 for too long.
                 setTimeLeft('...');
                 return;
            }

            const minutes = Math.floor(remainingMs / 60000);
            const seconds = Math.floor((remainingMs % 60000) / 1000);
            setTimeLeft(`${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`);
        };
        
        calculateTime();
        const timer = setInterval(calculateTime, 1000);

        return () => clearInterval(timer);
    }, [user.lives, user.lastLifeRegenTimestamp, appSettings]);

    const filteredAndSortedGames = useMemo(() => {
        return [...games]
            .sort((a, b) => {
                const aIsFav = user.favoriteGameIds.includes(a.id);
                const bIsFav = user.favoriteGameIds.includes(b.id);
                if (aIsFav && !bIsFav) return -1;
                if (!aIsFav && bIsFav) return 1;
                return a.name.localeCompare(b.name);
            });
    }, [games, user.favoriteGameIds]);

    useEffect(() => {
        const handleScroll = () => {
            if (window.innerHeight + document.documentElement.scrollTop < document.documentElement.offsetHeight - 200 || isLoadingMore || visibleCount >= filteredAndSortedGames.length) {
                return;
            }
            setIsLoadingMore(true);
            setTimeout(() => {
                setVisibleCount(prevCount => prevCount + GAMES_PER_PAGE);
                setIsLoadingMore(false);
            }, 500);
        };

        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, [isLoadingMore, visibleCount, filteredAndSortedGames.length]);
    
    const handleSaveProgress = (gameId: string) => {
        const currentProgress = user.gameProgress?.[gameId] || { level: 0 };
        const newProgress = {
            ...currentProgress,
            level: currentProgress.level + 1,
            lastSaved: new Date().toISOString(),
        };
        const updatedProgress = {
            ...user.gameProgress,
            [gameId]: newProgress
        };
        onUpdateUser(user.id, { gameProgress: updatedProgress });
    };

    const handlePlay = async (gameId: string) => {
        if (user.lives > 0 && !playingGameId) {
            setPlayingGameId(gameId);
            
            try {
                // API call will handle life decrement and timestamp update
                await onUpdateUser(user.id, { lives: user.lives - 1 });
            } catch (error) {
                setPlayingGameId(null); // Stop loading on error
                return;
            }


            // Simulate playing game for 3 seconds
            await new Promise(resolve => setTimeout(resolve, 3000));
            
            setPlayingGameId(null);

            const game = games.find(g => g.id === gameId);
            if (game?.supportsSave) {
                // Automatically save progress after playing
                handleSaveProgress(gameId);
            }
        }
    };

    return (
        <div className="animate-fade-in">
            {/* Header */}
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold text-gray-100">Juegos</h2>
                <div className="flex items-center space-x-3 bg-gray-800/70 p-2 rounded-lg shadow-md">
                    <div className={`flex items-center space-x-1.5 ${user.lives >= 5 ? 'animate-pulse' : ''}`}>
                        <HeartIcon className="w-6 h-6 text-red-500" />
                        <span className="font-bold text-xl text-red-400">{user.lives}</span>
                    </div>
                    {user.lives < 5 && appSettings.lifeRegenEnabled && (
                        <>
                            <div className="w-px h-5 bg-gray-600"></div>
                            <div className="text-sm text-cyan-400 font-mono" title="Time until next life">
                                <span>{timeLeft}</span>
                            </div>
                        </>
                    )}
                </div>
            </div>
            
            {/* Games Grid */}
            {filteredAndSortedGames.length > 0 ? (
                <>
                    <div className="grid grid-cols-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                        {filteredAndSortedGames.slice(0, visibleCount).map(game => (
                            <GameCard 
                                key={game.id}
                                game={game}
                                user={user}
                                onPlay={handlePlay}
                                onToggleFavorite={onToggleFavoriteGame}
                                isPlaying={playingGameId === game.id}
                            />
                        ))}
                    </div>
                    {isLoadingMore && (
                        <div className="flex justify-center items-center mt-6">
                            <Spinner />
                            <p className="ml-2">Cargando más juegos...</p>
                        </div>
                    )}
                </>
            ) : (
                 <div className="text-center py-16 px-6 bg-gray-800/70 backdrop-blur-sm rounded-xl shadow-lg">
                    <h3 className="text-xl font-semibold text-gray-200">No se encontraron juegos</h3>
                    <p className="text-gray-400 mt-2">No active games are available at the moment. Please check back later.</p>
                </div>
            )}
            
            {user.lives <= 0 && (
                <div className="mt-6 text-center p-4 bg-red-900/40 backdrop-blur-sm border border-red-500/30 rounded-xl shadow-lg">
                    <p className="font-semibold text-red-200">¡Te has quedado sin vidas! Visita la tienda para comprar más y seguir jugando.</p>
                </div>
            )}
        </div>
    );
};

export default GamesView;