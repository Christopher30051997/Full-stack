import React, { useState, useMemo, useEffect } from 'react';
import { Promotion, RequestStatus } from '../../types';
import { FacebookIcon, YouTubeIcon, TikTokIcon, CoinIcon } from '../../components/icons';
import Spinner from '../../components/Spinner';
import * as api from '../../services/api';

// FIX: Using a specific type for the creation payload to match the API.
type NewPromotionData = Omit<Promotion['details'], 'totalCost'> & { totalCost: number };
interface PromotionsViewProps {
    gemasGo: number;
    onNewPromotion: (promoData: NewPromotionData) => void;
}

const DURATION_COST_PER_15S = 0.05;
const VIEW_COST = 0.05;
const LIKE_COST = 0.05;
const COMMENT_COST = 0.10;


const UserPromotionsHistory: React.FC = () => {
    const [history, setHistory] = useState<Promotion[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchHistory = async () => {
            try {
                const data = await api.getUserPromotions();
                setHistory(data);
            } catch (error) {
                console.error("Failed to fetch promotion history:", error);
            } finally {
                setIsLoading(false);
            }
        };
        fetchHistory();
    }, []);
    
    const getStatusChip = (status: RequestStatus) => {
        switch (status) {
            case RequestStatus.APPROVED: return <span className="px-2 py-0.5 text-[10px] font-medium rounded-full bg-green-200 text-green-800">Approved</span>;
            case RequestStatus.REJECTED: return <span className="px-2 py-0.5 text-[10px] font-medium rounded-full bg-red-200 text-red-800">Rejected</span>;
            case RequestStatus.PENDING:
            default: return <span className="px-2 py-0.5 text-[10px] font-medium rounded-full bg-yellow-200 text-yellow-800">Pending</span>;
        }
    };

    if (isLoading) return <div className="flex justify-center p-8"><Spinner /></div>;

    if (history.length === 0) {
        return <p className="text-center text-gray-400 p-8 text-sm">No has enviado ninguna promoción todavía.</p>;
    }

    return (
        <div className="space-y-2 max-h-[60vh] overflow-y-auto pr-2">
            {history.map(promo => (
                <div key={promo.id} className="bg-gray-700/50 p-2 rounded-lg flex justify-between items-center text-xs">
                    <div>
                        <a href={promo.details.postUrl} target="_blank" rel="noopener noreferrer" className="font-semibold text-blue-400 hover:underline truncate block max-w-[150px] sm:max-w-xs">{promo.details.postUrl}</a>
                        <p className="text-gray-400 text-[10px] mt-1">
                            {new Date(promo.createdAt!).toLocaleDateString()} - Cost: {promo.details.totalCost.toFixed(2)} GemasGo
                        </p>
                    </div>
                    {getStatusChip(promo.status)}
                </div>
            ))}
        </div>
    );
};


const ValueSelector: React.FC<{ label: string; value: number; onUpdate: (value: number) => void; step: number; min: number; max: number; unit?: string; cost: number; }> = ({ label, value, onUpdate, step, min, max, unit, cost }) => {
    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        let numValue = parseInt(e.target.value, 10);
        if (isNaN(numValue)) {
            numValue = min;
        }
        const clampedValue = Math.max(min, Math.min(max, numValue));
        onUpdate(clampedValue);
    };
    
    return (
        <div className="flex items-center justify-between p-2 bg-gray-700 rounded-lg">
            <div className="text-xs">
                <span className="font-semibold text-gray-200">{label}</span>
                <p className="text-[10px] text-gray-400">Coste: {cost.toFixed(2)} GemasGo / {unit || 'unidad'}</p>
            </div>
            <div className="flex items-center space-x-1.5">
                <button type="button" onClick={() => onUpdate(Math.max(min, value - step))} className="w-6 h-6 rounded-full bg-gray-600 font-bold text-sm flex items-center justify-center">-</button>
                <input
                    type="number"
                    value={value}
                    onChange={handleInputChange}
                    min={min}
                    max={max}
                    className="w-12 text-center bg-gray-800 text-sm font-bold rounded-md border-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                />
                <button type="button" onClick={() => onUpdate(Math.min(max, value + step))} className="w-6 h-6 rounded-full bg-gray-600 font-bold text-sm flex items-center justify-center">+</button>
            </div>
        </div>
    );
};


const PromotionsView: React.FC<PromotionsViewProps> = ({ gemasGo, onNewPromotion }) => {
    const [socialMedia, setSocialMedia] = useState<'Facebook' | 'YouTube' | 'TikTok'>('Facebook');
    const [postUrl, setPostUrl] = useState('');
    const [duration, setDuration] = useState(15);
    const [views, setViews] = useState(0);
    const [likes, setLikes] = useState(0);
    const [comments, setComments] = useState(0);
    const [error, setError] = useState<string | null>(null);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [activeTab, setActiveTab] = useState<'create' | 'history'>('create');


    const totalCost = useMemo(() => {
        const durationCost = (duration / 15) * DURATION_COST_PER_15S;
        const viewsCost = views * VIEW_COST;
        const likesCost = likes * LIKE_COST;
        const commentsCost = comments * COMMENT_COST;
        return durationCost + viewsCost + likesCost + commentsCost;
    }, [duration, views, likes, comments]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);

        if (!postUrl.trim()) {
            setError('Por favor, introduce la URL de tu publicación.');
            return;
        }

        try {
            new URL(postUrl); 
        } catch (_) {
            setError('Por favor, introduce una URL válida.');
            return;
        }

        if (totalCost <= 0) {
            setError('La promoción debe tener un coste mayor que cero.');
            return;
        }

        if (gemasGo < totalCost) {
            setError('No tienes suficientes GemasGo para esta promoción.');
            return;
        }

        setIsSubmitting(true);
        try {
            await onNewPromotion({
                socialMedia,
                postUrl,
                duration,
                views,
                likes,
                comments,
                totalCost
            });
            
            setPostUrl('');
            setDuration(15);
            setViews(0);
            setLikes(0);
            setComments(0);
            // Switch to history tab after successful submission
            setActiveTab('history');
        } catch (err) {
            // Error notification is handled by parent
        } finally {
            setIsSubmitting(false);
        }
    };

    const getInactiveButtonClass = (platform: 'Facebook' | 'YouTube' | 'TikTok') => {
        let colorClass = 'text-gray-300'; // Default for Facebook
        if (platform === 'YouTube') {
            colorClass = 'text-red-600';
        }
        if (platform === 'TikTok') {
            colorClass = 'text-white';
        }
        return `bg-gray-800 border-gray-700 hover:bg-gray-700 ${colorClass}`;
    };

    const SocialButton: React.FC<{ platform: 'Facebook' | 'YouTube' | 'TikTok'; icon: React.ReactElement<{ className?: string }>; }> = ({ platform, icon }) => (
        <button
            type="button"
            onClick={() => setSocialMedia(platform)}
            className={`flex-1 flex items-center justify-center space-x-1.5 p-1.5 rounded-lg border-2 transition-colors duration-200 ${
                socialMedia === platform
                  ? 'bg-blue-600 border-blue-600 text-white'
                  : getInactiveButtonClass(platform)
            }`}
        >
            {React.cloneElement(icon, { className: "w-4 h-4" })}
            <span className="font-medium text-xs">{platform}</span>
        </button>
    );

    return (
        <div className="animate-fade-in">
            <h2 className="text-xl font-bold mb-3 text-pink-400">Tus Promociones</h2>
            <div className="bg-gray-800/70 backdrop-blur-sm p-4 rounded-xl shadow-lg max-w-2xl mx-auto">
                <div className="flex border-b border-gray-700 mb-4">
                    <button onClick={() => setActiveTab('create')} className={`px-4 py-2 text-sm font-semibold ${activeTab === 'create' ? 'text-pink-400 border-b-2 border-pink-400' : 'text-gray-400'}`}>Crear Nueva</button>
                    <button onClick={() => setActiveTab('history')} className={`px-4 py-2 text-sm font-semibold ${activeTab === 'history' ? 'text-pink-400 border-b-2 border-pink-400' : 'text-gray-400'}`}>Historial</button>
                </div>

                {activeTab === 'create' ? (
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div>
                            <label className="block text-xs font-medium text-gray-300 mb-1.5">Red Social</label>
                            <div className="flex space-x-2">
                                <SocialButton platform="Facebook" icon={<FacebookIcon />} />
                                <SocialButton platform="YouTube" icon={<YouTubeIcon />} />
                                <SocialButton platform="TikTok" icon={<TikTokIcon />} />
                            </div>
                        </div>
                        <div>
                            <label htmlFor="postUrl" className="block text-xs font-medium text-gray-300 mb-1.5">URL de la Publicación</label>
                            <input 
                                id="postUrl"
                                type="url"
                                value={postUrl}
                                onChange={(e) => setPostUrl(e.target.value)}
                                placeholder={`https://www.${socialMedia.toLowerCase()}.com/...`}
                                className="w-full p-2 bg-gray-700 rounded-md border border-gray-600 text-sm"
                            />
                        </div>

                        <div className="space-y-3">
                            <ValueSelector label="Duración del Video" value={duration} onUpdate={setDuration} step={15} min={15} max={300} unit="s" cost={DURATION_COST_PER_15S} />
                            <ValueSelector label="Vistas" value={views} onUpdate={setViews} step={1} min={0} max={1000} cost={VIEW_COST} />
                            <ValueSelector label="Me Gusta" value={likes} onUpdate={setLikes} step={1} min={0} max={500} cost={LIKE_COST} />
                            <ValueSelector label="Comentarios" value={comments} onUpdate={setComments} step={1} min={0} max={100} cost={COMMENT_COST} />
                        </div>

                        <div className="text-center bg-blue-900/40 p-2 rounded-lg">
                            <p className="font-semibold text-gray-200 text-xs">Coste Total de la Promoción:</p>
                            <div className="flex items-center justify-center space-x-1 mt-1">
                                <CoinIcon className="w-5 h-5 text-yellow-500" />
                                <span className="text-xl font-bold text-gray-100">{totalCost.toFixed(2)}</span>
                            </div>
                        </div>

                        {error && <p className="text-red-500 text-xs font-semibold text-center">{error}</p>}
                        
                        <button type="submit" className="w-full bg-pink-600 hover:bg-pink-700 text-white font-bold py-2 px-4 rounded-lg transition-transform transform hover:scale-105 disabled:bg-gray-400 text-sm" disabled={totalCost > gemasGo || isSubmitting}>
                            {isSubmitting ? <Spinner /> : gemasGo < totalCost ? 'GemasGo Insuficientes' : 'Pagar y Enviar para Revisión'}
                        </button>
                    </form>
                ) : (
                   <UserPromotionsHistory />
                )}
            </div>
        </div>
    );
};

export default PromotionsView;