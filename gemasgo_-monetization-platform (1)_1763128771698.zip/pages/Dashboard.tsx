import React, { useState, useMemo, useEffect, useRef } from 'react';
// FIX: Use specific types for creation payloads to align with App.tsx handlers
import { User, Game, Promotion, AdminMessage, AppSettings, NotificationType, PurchaseRequest, DiamondRedemption } from '../types';
import { GamepadIcon, TvIcon, StoreIcon, RocketIcon, SparklesIcon, LogoutIcon, EnvelopeIcon, CloseIcon, CoinIcon, UserIcon } from '../components/icons';
import GamesView from './dashboard/GamesView';
import AdsView from './dashboard/AdsView';
import StoreView from './dashboard/StoreView';
import PromotionsView from './dashboard/PromotionsView';
import GeminiToolsView from './dashboard/GeminiToolsView';
import OnboardingGuide from '../components/OnboardingGuide';

type View = 'games' | 'ads' | 'store' | 'promotions' | 'gemini';

// --- Local types for creation payloads to match server expectations ---
type NewPromotionData = Omit<Promotion['details'], 'totalCost'> & { totalCost: number };
type NewPurchaseRequestData = Omit<PurchaseRequest['details'], 'paymentProofUrl'>;
type NewDiamondRedemptionData = DiamondRedemption['details'];

interface DashboardProps {
  user: User;
  onLogout: () => void;
  games: Game[];
  promotions: Promotion[];
  adminMessages: AdminMessage[];
  appSettings: AppSettings;
  onNewPromotion: (promoData: NewPromotionData) => void;
  onNewPurchaseRequest: (requestData: NewPurchaseRequestData, proofKey: string) => Promise<boolean>;
  onNewDiamondRedemption: (requestData: NewDiamondRedemptionData) => void;
  onMarkMessagesAsRead: () => void;
  onToggleFavoriteGame: (gameId: string) => void;
  addNotification: (message: string, type: NotificationType) => void;
  onOnboardingComplete: () => void;
  onUpdateUser: (userId: string, updates: Partial<User>) => Promise<User | undefined>;
}

const MessageModal: React.FC<{ messages: AdminMessage[]; onClose: () => void; }> = ({ messages, onClose }) => (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center animate-fade-in" onClick={onClose}>
        <div className="bg-gray-800/80 backdrop-blur-sm rounded-xl shadow-2xl w-full max-w-lg m-4 animate-slide-in-up" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center p-4 border-b border-gray-700">
                <h3 className="text-xl font-bold">Mensajes del Administrador</h3>
                <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-700"><CloseIcon className="w-6 h-6" /></button>
            </div>
            <div className="p-6 max-h-[70vh] overflow-y-auto space-y-4">
                {messages.length > 0 ? (
                    messages.slice().reverse().map(msg => (
                        <div key={msg.id} className="p-4 bg-gray-900/50 rounded-lg border border-gray-700">
                            <p className="text-gray-200">{msg.text}</p>
                            {msg.photoUrl && <img src={msg.photoUrl} alt="Proof" className="mt-3 rounded-lg max-w-xs" />}
                            <p className="text-xs text-gray-400 mt-2 text-right">{new Date(msg.createdAt || msg.timestamp).toLocaleString()}</p>
                        </div>
                    ))
                ) : (
                    <p className="text-center text-gray-500 py-8">No tienes mensajes.</p>
                )}
            </div>
        </div>
    </div>
);

const navConfig: { [key in View]: { color: 'purple' | 'cyan' | 'green' | 'pink' | 'blue'; icon: React.ReactElement<{ className?: string }> } } = {
    games: { color: 'purple', icon: <GamepadIcon /> },
    ads: { color: 'cyan', icon: <TvIcon /> },
    store: { color: 'green', icon: <StoreIcon /> },
    promotions: { color: 'pink', icon: <RocketIcon /> },
    gemini: { color: 'blue', icon: <SparklesIcon /> },
};

const borderClassMap: { [key in View]: string } = {
    games: 'animated-border-purple',
    ads: 'animated-border-cyan',
    store: 'animated-border-green',
    promotions: 'animated-border-pink',
    gemini: 'animated-border-blue',
};

const Dashboard: React.FC<DashboardProps> = (props) => {
    const { user, onLogout, games, promotions, adminMessages, onMarkMessagesAsRead, appSettings, addNotification, onOnboardingComplete, onUpdateUser } = props;
    const [view, setView] = useState<View>('games');
    const [isMessagesOpen, setIsMessagesOpen] = useState(false);
    const navContainerRef = useRef<HTMLDivElement>(null);
    const followerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const navContainer = navContainerRef.current;
        const followerElement = followerRef.current;
        if (!navContainer || !followerElement) return;

        const handleMouseMove = (e: MouseEvent) => {
            if (followerElement) {
                followerElement.style.top = `${e.clientY}px`;
                followerElement.style.left = `${e.clientX}px`;
            }
        };

        const handleMouseEnter = () => {
            if (followerElement) followerElement.classList.add('visible');
        };

        const handleMouseLeave = () => {
            if (followerElement) followerElement.classList.remove('visible');
        };

        navContainer.addEventListener('mousemove', handleMouseMove);
        navContainer.addEventListener('mouseenter', handleMouseEnter);
        navContainer.addEventListener('mouseleave', handleMouseLeave);
        
        return () => {
            navContainer.removeEventListener('mousemove', handleMouseMove);
            navContainer.removeEventListener('mouseenter', handleMouseEnter);
            navContainer.removeEventListener('mouseleave', handleMouseLeave);
        };
    }, []);

    const unreadMessagesCount = useMemo(() => adminMessages.filter(m => !m.read).length, [adminMessages]);

    const handleOpenMessages = () => {
        setIsMessagesOpen(true);
        if (unreadMessagesCount > 0) {
            onMarkMessagesAsRead();
        }
    };

    const NavButton: React.FC<{ viewName: View; label: string; id: string; }> = ({ viewName, label, id }) => {
        const { color, icon } = navConfig[viewName];
        const isActive = view === viewName;
    
        const activeClasses: { [key: string]: string } = {
            purple: 'bg-purple-900/60 text-purple-300',
            cyan: 'bg-cyan-900/60 text-cyan-300',
            green: 'bg-green-900/60 text-green-300',
            pink: 'bg-pink-900/60 text-pink-300',
            blue: 'bg-blue-900/60 text-blue-300',
        };
        
        const baseClasses = "relative z-20 flex flex-col items-center justify-center space-y-1 w-14 h-14 sm:w-16 rounded-lg transition-all duration-300 has-tooltip";
        const inactiveClasses = "text-gray-400 hover:bg-gray-800/70";
    
        const buttonEl = (
            <button
                id={id}
                onClick={() => setView(viewName)}
                aria-label={label}
                className={`${baseClasses} ${isActive ? activeClasses[color] : inactiveClasses} ${!isActive ? 'transform hover:-translate-y-1' : ''}`}
            >
                {React.cloneElement(icon, { className: `w-5 h-5 sm:w-6 sm:h-6` })}
                <span className="text-[10px] font-bold" aria-hidden="true">{label}</span>
                <div className="tooltip tooltip-bottom" role="tooltip">{label}</div>
            </button>
        );

        if (isActive) {
            return (
                <div className={`animated-border-container ${borderClassMap[viewName]} transform hover:-translate-y-1 transition-transform duration-300`}>
                    <div className="relative z-10">
                        {buttonEl}
                    </div>
                </div>
            );
        }

        return buttonEl;
    };

    return (
        <div className="text-gray-200 min-h-screen">
             {user.isNewUser && <OnboardingGuide onComplete={onOnboardingComplete} />}
             {isMessagesOpen && <MessageModal messages={adminMessages} onClose={() => setIsMessagesOpen(false)} />}
            
            <header className="fixed top-0 left-0 right-0 bg-gray-900/80 backdrop-blur-sm shadow-md z-40">
                {/* Top Row */}
                <div className="flex items-center justify-between h-14 px-2 sm:px-4">
                    <div id="user-info-header" className="flex items-center space-x-2 bg-gray-700/70 pl-1 pr-2 py-1 rounded-full">
                       <div className="w-7 h-7 rounded-full bg-gray-800 flex items-center justify-center">
                           <UserIcon className="w-4 h-4 text-gray-400" />
                       </div>
                       <span className="font-semibold text-sm">{user.name}</span>
                       <div className="w-px h-4 bg-gray-600"></div>
                       <div className="flex items-center space-x-1">
                           <CoinIcon className="w-4 h-4 text-yellow-500" />
                           <span className="font-semibold text-sm text-yellow-500">{user.gemasGo.toFixed(2)}</span>
                       </div>
                    </div>
                    <div className="flex items-center space-x-1 sm:space-x-2">
                        <div className="relative">
                            <button onClick={handleOpenMessages} className="p-1.5 rounded-full hover:bg-gray-700/70">
                                <EnvelopeIcon className="w-5 h-5" />
                            </button>
                            {unreadMessagesCount > 0 && <div className="absolute top-0 right-0 w-3.5 h-3.5 bg-red-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center">{unreadMessagesCount}</div>}
                        </div>
                        <button onClick={onLogout} className="p-1.5 rounded-full hover:bg-gray-700/70">
                            <LogoutIcon className="w-5 h-5 text-red-500" />
                        </button>
                    </div>
                </div>
                {/* Second Row */}
                <div className="p-1 relative">
                    <div ref={navContainerRef}>
                        <nav className="h-16 flex justify-center items-center rounded-lg relative z-10 overflow-hidden animate-nav-background-pan">
                            <div className="flex justify-center items-center space-x-2">
                                <NavButton id="nav-games" viewName="games" label="Juegos" />
                                <NavButton id="nav-ads" viewName="ads" label="Anuncios" />
                                <NavButton id="nav-store" viewName="store" label="Tienda" />
                                <NavButton id="nav-promotions" viewName="promotions" label="Promociones" />
                                <NavButton id="nav-gemini" viewName="gemini" label="AI Tools" />
                            </div>
                        </nav>
                    </div>
                </div>
            </header>

            <main className="pt-32 p-2 sm:p-4">
                <div style={{ display: view === 'games' ? 'block' : 'none' }}>
                    <GamesView games={games} user={user} onUpdateUser={onUpdateUser} onToggleFavoriteGame={props.onToggleFavoriteGame} appSettings={appSettings} />
                </div>
                 <div style={{ display: view === 'ads' ? 'block' : 'none' }}>
                    <AdsView promotions={promotions} />
                </div>
                 <div style={{ display: view === 'store' ? 'block' : 'none' }}>
                    <StoreView user={user} appSettings={props.appSettings} onNewPurchaseRequest={props.onNewPurchaseRequest} onNewDiamondRedemption={props.onNewDiamondRedemption} onUpdateUser={onUpdateUser} addNotification={addNotification} />
                </div>
                 <div style={{ display: view === 'promotions' ? 'block' : 'none' }}>
                    <PromotionsView gemasGo={user.gemasGo} onNewPromotion={props.onNewPromotion} />
                </div>
                 <div style={{ display: view === 'gemini' ? 'block' : 'none' }}>
                    <GeminiToolsView />
                </div>
            </main>
            <div ref={followerRef} className="nav-follower"></div>
        </div>
    );
};

export default Dashboard;