import React, { useState, useMemo, useEffect } from 'react';
import { User, Promotion, RequestStatus, NotificationType, AnyRequest, Game, StoreItem, AppSettings, AISystemSettings, PurchaseRequest, DiamondRedemption } from '../types';
import { LogoutIcon, EnvelopeIcon, CheckCircleIcon, XCircleIcon, SparklesIcon, GamepadIcon, StoreIcon, RocketIcon, CoinIcon, CloseIcon, PencilIcon, TrashIcon, PlusCircleIcon, UserIcon } from '../components/icons';
import Spinner from '../components/Spinner';
import ConfirmationModal from '../components/ConfirmationModal';

type AdminView = 'requests' | 'manage-games' | 'manage-store' | 'ai-systems';

// --- HELPER COMPONENTS ---

const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
  });
};

// --- GAME MANAGEMENT ---

const GameFormModal: React.FC<{ game: Game | null, onSave: (game: Game) => void, onClose: () => void }> = ({ game, onSave, onClose }) => {
    const [formData, setFormData] = useState<Partial<Game>>(game || { name: '', description: '', genre: 'Puzzle', isActive: true });
    const [imageFile, setImageFile] = useState<File | null>(null);
    const [gameFile, setGameFile] = useState<File | null>(null);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };
    
    const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files) setImageFile(e.target.files[0]);
    };

    const handleGameFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files) setGameFile(e.target.files[0]);
    }

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        let imageUrl = formData.imageUrl;
        if (imageFile) {
            imageUrl = await fileToBase64(imageFile);
        }
        const gameFileName = gameFile ? gameFile.name : formData.gameFileName;
        onSave({ ...formData, imageUrl, gameFileName, id: formData.id || `g-${Date.now()}` } as Game);
    };
    
    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center animate-fade-in" onClick={onClose}>
            <div className="bg-gray-800/80 backdrop-blur-sm p-4 rounded-lg w-full max-w-lg m-4" onClick={e => e.stopPropagation()}>
                <h3 className="text-xl font-bold mb-4">{game ? 'Edit Game' : 'Add New Game'}</h3>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <input name="name" value={formData.name} onChange={handleChange} placeholder="Game Name" className="w-full p-2 bg-gray-700 rounded-md" required />
                    <textarea name="description" value={formData.description} onChange={handleChange} placeholder="Description" className="w-full p-2 bg-gray-700 rounded-md" required />
                    <select name="genre" value={formData.genre} onChange={handleChange} className="w-full p-2 bg-gray-700 rounded-md">
                        <option>Puzzle</option><option>Arcade</option><option>Strategy</option><option>Platformer</option><option>Action</option>
                    </select>
                    <input name="developer" value={formData.developer || ''} onChange={handleChange} placeholder="Developer" className="w-full p-2 bg-gray-700 rounded-md" />
                    <input name="publisher" value={formData.publisher || ''} onChange={handleChange} placeholder="Publisher" className="w-full p-2 bg-gray-700 rounded-md" />
                    <div>
                        <label htmlFor="releaseDate" className="text-sm text-gray-400">Release Date</label>
                        <input id="releaseDate" name="releaseDate" type="date" value={formData.releaseDate || ''} onChange={handleChange} className="w-full p-2 bg-gray-700 rounded-md" />
                    </div>
                    <div>
                        <label className="text-sm">Cover Image (Optional)</label>
                        <input type="file" accept="image/*" onChange={handleImageChange} className="w-full text-sm mt-1 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-900/50 file:text-blue-300 hover:file:bg-blue-900" />
                    </div>
                     <div>
                        <label className="text-sm">Game File (.zip, .exe)</label>
                        <input type="file" accept=".zip,.rar,.exe,.7z" onChange={handleGameFileChange} className="w-full text-sm mt-1 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-900/50 file:text-blue-300 hover:file:bg-blue-900" />
                        {(gameFile?.name || formData.gameFileName) && <p className="text-xs text-gray-400 mt-1">Selected: {gameFile?.name || formData.gameFileName}</p>}
                    </div>
                    <div className="flex justify-end space-x-2">
                        <button type="button" onClick={onClose} className="px-4 py-2 rounded-lg bg-gray-600">Cancel</button>
                        <button type="submit" className="px-4 py-2 rounded-lg bg-blue-600 text-white">Save Game</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

const ManageGamesView: React.FC<{ games: Game[], onSetGames: (games: Game[]) => void, addNotification: (msg: string, type: NotificationType) => void }> = ({ games, onSetGames, addNotification }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingGame, setEditingGame] = useState<Game | null>(null);
    const [deletingGame, setDeletingGame] = useState<Game | null>(null);

    const handleSaveGame = (gameToSave: Game) => {
        const isNew = !games.some(g => g.id === gameToSave.id);
        const updatedGames = isNew ? [...games, gameToSave] : games.map(g => g.id === gameToSave.id ? gameToSave : g);
        onSetGames(updatedGames);
        addNotification(`Game successfully ${isNew ? 'added' : 'updated'}!`, 'success');
        setIsModalOpen(false);
        setEditingGame(null);
    };

    const handleDeleteGame = () => {
        if (!deletingGame) return;
        onSetGames(games.filter(g => g.id !== deletingGame.id));
        addNotification('Game deleted.', 'success');
        setDeletingGame(null);
    };
    
    const handleToggleActive = (gameId: string) => {
        onSetGames(games.map(g => g.id === gameId ? {...g, isActive: !g.isActive } : g));
    }

    return (
        <div className="animate-fade-in">
            {isModalOpen && <GameFormModal game={editingGame} onSave={handleSaveGame} onClose={() => { setIsModalOpen(false); setEditingGame(null); }} />}
            {deletingGame && (
                <ConfirmationModal 
                    isOpen={!!deletingGame}
                    title="Delete Game" 
                    onClose={() => setDeletingGame(null)} 
                    onConfirm={handleDeleteGame}
                    confirmText="Delete"
                >
                   <p>Are you sure you want to delete the game "<strong>{deletingGame.name}</strong>"? This action cannot be undone.</p> 
                </ConfirmationModal>
            )}
            <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold">Manage Games</h3>
                <button onClick={() => setIsModalOpen(true)} className="flex items-center space-x-1.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm py-1.5 px-3 rounded-lg"><PlusCircleIcon className="w-5 h-5"/><span>Add Game</span></button>
            </div>
            <div className="overflow-x-auto bg-gray-800/70 backdrop-blur-sm rounded-lg shadow-md">
                <table className="w-full text-sm text-left">
                    <thead className="bg-gray-700/80 text-xs uppercase"><tr><th className="px-4 py-2">Name</th><th className="px-4 py-2">Genre</th><th className="px-4 py-2">Active Status</th><th className="px-4 py-2">Actions</th></tr></thead>
                    <tbody>
                        {games.map(game => (
                            <tr key={game.id} className="border-b border-gray-700">
                                <td className="px-4 py-3 font-medium text-sm">{game.name}</td>
                                <td className="px-4 py-3 text-sm">{game.genre}</td>
                                <td className="px-4 py-3">
                                    <div className="flex items-center space-x-3">
                                        <label className="relative inline-flex items-center cursor-pointer">
                                            <input
                                                type="checkbox"
                                                checked={game.isActive}
                                                onChange={() => handleToggleActive(game.id)}
                                                className="sr-only peer"
                                            />
                                            <div className="w-11 h-6 bg-gray-600 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-500 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-500"></div>
                                        </label>
                                         <span className={`text-xs font-medium ${game.isActive ? 'text-green-400' : 'text-gray-400'}`}>
                                            {game.isActive ? 'Active' : 'Inactive'}
                                        </span>
                                    </div>
                                </td>
                                <td className="px-4 py-3 flex space-x-3">
                                    <button onClick={() => { setEditingGame(game); setIsModalOpen(true); }}><PencilIcon className="w-5 h-5 text-yellow-500 hover:text-yellow-600"/></button>
                                    <button onClick={() => setDeletingGame(game)}><TrashIcon className="w-5 h-5 text-red-500 hover:text-red-600"/></button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

// --- STORE MANAGEMENT ---
const StoreItemFormModal: React.FC<{ item: StoreItem | null, onSave: (item: StoreItem) => void, onClose: () => void }> = ({ item, onSave, onClose }) => {
    const [formData, setFormData] = useState<Partial<StoreItem>>(item || { name: '', description: '', cost: 1, type: 'diamond-pack', amount: 100, isActive: true });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        const isNumeric = ['cost', 'amount'].includes(name);
        setFormData(prev => ({ ...prev, [name]: isNumeric ? parseFloat(value) : value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({ ...formData, id: formData.id || `s-${Date.now()}` } as StoreItem);
    };
    
    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center animate-fade-in" onClick={onClose}>
            <div className="bg-gray-800/80 backdrop-blur-sm p-4 rounded-lg w-full max-w-lg m-4" onClick={e => e.stopPropagation()}>
                <h3 className="text-xl font-bold mb-4">{item ? 'Edit Store Item' : 'Add New Store Item'}</h3>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <input name="name" value={formData.name} onChange={handleChange} placeholder="Item Name" className="w-full p-2 bg-gray-700 rounded-md" required />
                    <textarea name="description" value={formData.description} onChange={handleChange} placeholder="Description" className="w-full p-2 bg-gray-700 rounded-md" required />
                    <input name="cost" type="number" step="0.01" value={formData.cost} onChange={handleChange} placeholder="Cost (GemasGo)" className="w-full p-2 bg-gray-700 rounded-md" required />
                    <input name="amount" type="number" value={formData.amount} onChange={handleChange} placeholder="Amount (e.g., 100 diamonds)" className="w-full p-2 bg-gray-700 rounded-md" required />
                    <select name="type" value={formData.type} onChange={handleChange} className="w-full p-2 bg-gray-700 rounded-md">
                        <option value="diamond-pack">Diamond Pack</option>
                        <option value="lives">Lives</option>
                        <option value="gemas">Gemas</option>
                    </select>
                    <div className="flex justify-end space-x-2">
                        <button type="button" onClick={onClose} className="px-4 py-2 rounded-lg bg-gray-600">Cancel</button>
                        <button type="submit" className="px-4 py-2 rounded-lg bg-blue-600 text-white">Save Item</button>
                    </div>
                </form>
            </div>
        </div>
    );
};


const ManageStoreView: React.FC<{ storeItems: StoreItem[], onSetStoreItems: (items: StoreItem[]) => void, appSettings: AppSettings, onSetAppSettings: (settings: AppSettings) => void, addNotification: (msg: string, type: NotificationType) => void }> = (props) => {
    const { storeItems, onSetStoreItems, appSettings, onSetAppSettings, addNotification } = props;
    const [localSettings, setLocalSettings] = useState(appSettings);

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingItem, setEditingItem] = useState<StoreItem | null>(null);
    const [deletingItemId, setDeletingItemId] = useState<string | null>(null);
    
    const handleSettingsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value, type } = e.target;
        setLocalSettings(prev => ({...prev, [name]: type === 'number' ? parseFloat(value) : value }))
    };

    const handleSaveSettings = () => {
        onSetAppSettings(localSettings);
        addNotification('App settings updated!', 'success');
    }
    
    const handleSaveItem = (itemToSave: StoreItem) => {
        const isNew = !storeItems.some(i => i.id === itemToSave.id);
        const updatedItems = isNew ? [...storeItems, itemToSave] : storeItems.map(i => i.id === itemToSave.id ? itemToSave : i);
        onSetStoreItems(updatedItems);
        addNotification(`Store item successfully ${isNew ? 'added' : 'updated'}!`, 'success');
        setIsModalOpen(false);
        setEditingItem(null);
    };

    const handleDeleteItem = () => {
        if (!deletingItemId) return;
        onSetStoreItems(storeItems.filter(i => i.id !== deletingItemId));
        addNotification('Store item deleted.', 'success');
        setDeletingItemId(null);
    };

    const handleToggleActive = (itemId: string) => {
        onSetStoreItems(storeItems.map(i => i.id === itemId ? {...i, isActive: !i.isActive } : i));
    };

    return (
        <div className="animate-fade-in space-y-8">
            {isModalOpen && <StoreItemFormModal item={editingItem} onSave={handleSaveItem} onClose={() => { setIsModalOpen(false); setEditingItem(null); }} />}
            {deletingItemId && <ConfirmationModal isOpen={!!deletingItemId} confirmText="Delete" title="Delete Store Item" onClose={() => setDeletingItemId(null)} onConfirm={handleDeleteItem}>Are you sure you want to delete this item? This action cannot be undone.</ConfirmationModal>}

            <div>
                 <h3 className="text-xl font-bold mb-4">Manage App Settings</h3>
                 <div className="bg-gray-800/70 backdrop-blur-sm p-4 rounded-lg shadow-md max-w-md space-y-4">
                    <div>
                        <label htmlFor="livesCost" className="block text-sm font-medium">Lives Cost (GemasGo)</label>
                        <input type="number" name="livesCost" id="livesCost" value={localSettings.livesCost} onChange={handleSettingsChange} step="0.01" className="w-full p-2 bg-gray-700 rounded-md mt-1" />
                    </div>
                    <div>
                        <label htmlFor="cryptoCurrency" className="block text-sm font-medium">Crypto Currency</label>
                        <input type="text" name="cryptoCurrency" id="cryptoCurrency" value={localSettings.cryptoCurrency} onChange={handleSettingsChange} placeholder="e.g., USDT" className="w-full p-2 bg-gray-700 rounded-md mt-1" />
                    </div>
                     <div>
                        <label htmlFor="cryptoAddress" className="block text-sm font-medium">Crypto Wallet Address</label>
                        <input type="text" name="cryptoAddress" id="cryptoAddress" value={localSettings.cryptoAddress} onChange={handleSettingsChange} placeholder="Wallet Address" className="w-full p-2 bg-gray-700 rounded-md mt-1" />
                    </div>
                    <button onClick={handleSaveSettings} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg">Save Settings</button>
                 </div>
            </div>
            <div>
                 <div className="flex justify-between items-center mb-2">
                    <h3 className="text-xl font-bold">Manage Store Items</h3>
                     <button onClick={() => setIsModalOpen(true)} className="flex items-center space-x-1.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm py-1.5 px-3 rounded-lg"><PlusCircleIcon className="w-5 h-5"/><span>Add Item</span></button>
                </div>
                 <div className="overflow-x-auto bg-gray-800/70 backdrop-blur-sm rounded-lg shadow-md">
                     <table className="w-full text-sm text-left">
                        <thead className="bg-gray-700/80 text-xs uppercase"><tr><th className="px-4 py-2">Name</th><th className="px-4 py-2">Cost</th><th className="px-4 py-2">Type</th><th className="px-4 py-2">Amount</th><th className="px-4 py-2">Status</th><th className="px-4 py-2">Actions</th></tr></thead>
                        <tbody>
                            {storeItems.map(item => (
                                <tr key={item.id} className="border-b border-gray-700">
                                    <td className="px-4 py-3 text-sm font-medium">{item.name}</td>
                                    <td className="px-4 py-3 text-sm">{item.cost.toFixed(2)}</td>
                                    <td className="px-4 py-3 text-sm capitalize">{item.type.replace('-',' ')}</td>
                                    <td className="px-4 py-3 text-sm">{item.amount}</td>
                                    <td className="px-4 py-3"><span onClick={() => handleToggleActive(item.id)} className={`px-2 py-1 text-xs rounded-full cursor-pointer ${item.isActive ? 'bg-green-200 text-green-800' : 'bg-red-200 text-red-800'}`}>{item.isActive ? 'Active' : 'Inactive'}</span></td>
                                    <td className="px-4 py-3 flex space-x-3">
                                        <button onClick={() => { setEditingItem(item); setIsModalOpen(true); }}><PencilIcon className="w-5 h-5 text-yellow-500 hover:text-yellow-600"/></button>
                                        <button onClick={() => setDeletingItemId(item.id)}><TrashIcon className="w-5 h-5 text-red-500 hover:text-red-600"/></button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    )
};

const RequestTable: React.FC<{ requests: AnyRequest[]; onReview: (id: string, status: RequestStatus) => void; onImageView: (url: string) => void }> = ({ requests, onReview, onImageView }) => {
    const getStatusChip = (status: RequestStatus) => {
        switch (status) {
            case RequestStatus.APPROVED: return <span className="px-2 py-1 text-xs font-medium rounded-full bg-green-200 text-green-800">Approved</span>;
            case RequestStatus.REJECTED: return <span className="px-2 py-1 text-xs font-medium rounded-full bg-red-200 text-red-800">Rejected</span>;
            case RequestStatus.PENDING:
            default: return <span className="px-2 py-1 text-xs font-medium rounded-full bg-yellow-200 text-yellow-800">Pending</span>;
        }
    };
    
    return (
      <div className="overflow-x-auto bg-gray-800/70 backdrop-blur-sm rounded-lg shadow-md">
        <table className="w-full text-sm text-left">
            <thead className="bg-gray-700/80 text-xs uppercase">
                <tr>
                    <th className="px-4 py-2">User</th>
                    <th className="px-4 py-2">Type</th>
                    <th className="px-4 py-2">Details</th>
                    <th className="px-4 py-2">Status</th>
                    <th className="px-4 py-2">AI Review</th>
                    <th className="px-4 py-2">Actions</th>
                </tr>
            </thead>
            <tbody>
                {requests.length === 0 ? (
                    <tr><td colSpan={6} className="text-center py-8 text-gray-400">No requests match the current filter.</td></tr>
                ) : (
                    requests.map(req => (
                        <tr key={req.id} className="border-b border-gray-700 text-sm">
                            <td className="px-4 py-3 font-medium">{req.userName}</td>
                            {/* FIX: Use `req.type` which exists on the base Transaction type */}
                            <td className="px-4 py-3">{req.type}</td>
                            <td className="px-4 py-3">
                                {/* FIX: Correctly check for properties within the nested `details` object */}
                                {req.type === 'PROMOTION' && req.details.postUrl && <a href={req.details.postUrl} className="text-blue-500 hover:underline" target="_blank" rel="noopener noreferrer">View Post</a>}
                                {req.type === 'PURCHASE' && req.details.amountGemas && <span>{req.details.amountGemas} GemasGo for ${req.details.amountUSD} {req.details.paymentProofUrl && <button onClick={() => onImageView(req.details.paymentProofUrl!)} className="ml-2 text-xs text-blue-400 hover:underline">(View Proof)</button>}</span>}
                                {req.type === 'REDEMPTION' && req.details.diamondAmount && <span>{req.details.diamondAmount} FF Diamonds for {req.details.gemasGoCost} GemasGo (ID: {req.details.ffUserId})</span>}
                            </td>
                            <td className="px-4 py-3">{getStatusChip(req.status)}</td>
                            <td className="px-4 py-3 text-xs">
                                {(req.aiReview) ? (
                                    <div className="flex flex-col gap-1 items-start">
                                        <span className={`px-2 py-0.5 self-start rounded-full ${req.aiReview.status === 'Approved' ? 'bg-green-200 text-green-800' : req.aiReview.status === 'Flagged' ? 'bg-red-200 text-red-800' : 'bg-gray-200 text-gray-800'}`}>
                                            {req.aiReview.status}
                                        </span>
                                        {req.aiReview.reason && (
                                            <span className="text-gray-400" title={req.aiReview.reason}>
                                                {req.aiReview.reason}
                                            </span>
                                        )}
                                    </div>
                                ) : (
                                    <span className="text-gray-500">N/A</span>
                                )}
                            </td>
                            <td className="px-4 py-3">
                                {req.status === RequestStatus.PENDING ? (
                                    <div className="flex space-x-2">
                                        <button onClick={() => onReview(req.id, RequestStatus.APPROVED)} title="Approve"><CheckCircleIcon className="w-6 h-6 text-green-500 hover:text-green-600"/></button>
                                        <button onClick={() => onReview(req.id, RequestStatus.REJECTED)} title="Reject"><XCircleIcon className="w-6 h-6 text-red-500 hover:text-red-600"/></button>
                                    </div>
                                ) : (
                                    <span className="text-xs text-gray-500">—</span>
                                )}
                            </td>
                        </tr>
                    ))
                )}
            </tbody>
        </table>
      </div>
    );
};


const ManageAISystems: React.FC<{ settings: AISystemSettings, onUpdate: (settings: AISystemSettings) => void }> = ({ settings, onUpdate }) => {
    const [localSettings, setLocalSettings] = useState(settings);

    useEffect(() => {
        setLocalSettings(settings);
    }, [settings]);

    const handleUpdate = <K extends keyof AISystemSettings, P extends keyof AISystemSettings[K]>(system: K, prop: P, value: AISystemSettings[K][P]) => {
        setLocalSettings(prev => ({
            ...prev,
            [system]: {
                ...prev[system],
                [prop]: value
            }
        }));
    };

    const handleThresholdUpdate = (type: 'purchase' | 'redemption', value: number) => {
        setLocalSettings(prev => ({
            ...prev,
            transactionMonitoring: {
                ...prev.transactionMonitoring,
                riskThresholds: {
                    ...prev.transactionMonitoring.riskThresholds,
                    [type]: value
                }
            }
        }));
    };
    
    const renderToggle = (system: keyof AISystemSettings) => (
         <label className="relative inline-flex items-center cursor-pointer">
            <input type="checkbox" checked={localSettings[system].isActive} onChange={(e) => handleUpdate(system, 'isActive', e.target.checked)} className="sr-only peer" />
            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full dark:bg-gray-600 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-500 peer-checked:bg-blue-600"></div>
        </label>
    );

    return (
        <div className="space-y-6">
             <div className="p-4 bg-gray-800/70 backdrop-blur-sm rounded-lg shadow-md">
                <div className="flex justify-between items-center mb-4">
                    <h4 className="font-bold text-lg">AI Ad Revenue Split</h4>
                    {renderToggle('adRevenueSplit')}
                </div>
                <div className={!localSettings.adRevenueSplit.isActive ? 'opacity-50' : ''}>
                    <label className="block text-sm font-medium">User Percentage ({localSettings.adRevenueSplit.userPercentage}%)</label>
                    <input 
                        type="range" 
                        min="0" max="100" 
                        value={localSettings.adRevenueSplit.userPercentage}
                        onChange={(e) => handleUpdate('adRevenueSplit', 'userPercentage', parseInt(e.target.value))}
                        className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer custom-slider"
                        disabled={!localSettings.adRevenueSplit.isActive}
                    />
                </div>
            </div>
             <div className="p-4 bg-gray-800/70 backdrop-blur-sm rounded-lg shadow-md">
                <div className="flex justify-between items-center mb-4">
                    <h4 className="font-bold text-lg">AI Anti-Fraud System</h4>
                    {renderToggle('antiFraud')}
                </div>
                <div className={`space-y-4 ${!localSettings.antiFraud.isActive ? 'opacity-50' : ''}`}>
                    <div className="flex items-center space-x-2">
                        <input 
                            type="checkbox" 
                            id="promo-validation"
                            checked={localSettings.antiFraud.enablePromotionValidation}
                            onChange={(e) => handleUpdate('antiFraud', 'enablePromotionValidation', e.target.checked)}
                            disabled={!localSettings.antiFraud.isActive}
                            className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                        />
                         <label htmlFor="promo-validation" className="text-sm font-medium">Enable AI Promotion Validation</label>
                    </div>
                     <div className="space-y-2">
                        <label className="text-sm font-medium">Fraud Detection Sensitivity</label>
                        <select
                            value={localSettings.antiFraud.sensitivity}
                            onChange={(e) => handleUpdate('antiFraud', 'sensitivity', e.target.value as 'low' | 'medium' | 'high')}
                            disabled={!localSettings.antiFraud.isActive}
                            className="w-full p-2 bg-gray-700 rounded-md border border-gray-600"
                        >
                            <option value="low">Low</option>
                            <option value="medium">Medium</option>
                            <option value="high">High</option>
                        </select>
                    </div>
                </div>
            </div>
             <div className="p-4 bg-gray-800/70 backdrop-blur-sm rounded-lg shadow-md">
                <div className="flex justify-between items-center mb-4">
                    <h4 className="font-bold text-lg">AI Transaction Monitoring</h4>
                    {renderToggle('transactionMonitoring')}
                </div>
                <div className={`space-y-4 ${!localSettings.transactionMonitoring.isActive ? 'opacity-50' : ''}`}>
                     <div>
                        <label className="block text-sm font-medium">Purchase Request Risk Threshold ({localSettings.transactionMonitoring.riskThresholds.purchase}%)</label>
                        <p className="text-xs text-gray-400 mb-2">Flags purchases riskier than this value.</p>
                        <input 
                            type="range" 
                            min="0" max="100" 
                            value={localSettings.transactionMonitoring.riskThresholds.purchase}
                            onChange={(e) => handleThresholdUpdate('purchase', parseInt(e.target.value))}
                            className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer custom-slider"
                            disabled={!localSettings.transactionMonitoring.isActive}
                        />
                    </div>
                     <div>
                        <label className="block text-sm font-medium">Diamond Redemption Risk Threshold ({localSettings.transactionMonitoring.riskThresholds.redemption}%)</label>
                        <p className="text-xs text-gray-400 mb-2">Flags redemptions riskier than this value.</p>
                        <input 
                            type="range" 
                            min="0" max="100" 
                            value={localSettings.transactionMonitoring.riskThresholds.redemption}
                            onChange={(e) => handleThresholdUpdate('redemption', parseInt(e.target.value))}
                            className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer custom-slider"
                            disabled={!localSettings.transactionMonitoring.isActive}
                        />
                    </div>
                    <div className="flex items-center justify-between">
                         <label htmlFor="auto-block-transactions" className="text-sm font-medium">Auto-block high-risk transactions</label>
                         <label className="relative inline-flex items-center cursor-pointer">
                            <input
                                type="checkbox"
                                id="auto-block-transactions"
                                checked={localSettings.transactionMonitoring.autoBlock}
                                onChange={(e) => handleUpdate('transactionMonitoring', 'autoBlock', e.target.checked)}
                                disabled={!localSettings.transactionMonitoring.isActive}
                                className="sr-only peer"
                            />
                             <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full dark:bg-gray-600 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-500 peer-checked:bg-blue-600"></div>
                        </label>
                    </div>
                </div>
            </div>
            <div className="p-4 bg-gray-800/70 backdrop-blur-sm rounded-lg shadow-md">
                <div className="flex justify-between items-center mb-4">
                    <h4 className="font-bold text-lg">AI Notification System</h4>
                    {renderToggle('notificationSystem')}
                </div>
                <div className={`space-y-4 ${!localSettings.notificationSystem.isActive ? 'opacity-50' : ''}`}>
                    <div className="flex items-center justify-between">
                         <label htmlFor="proactive-notifications" className="text-sm font-medium">Enable Proactive Notifications</label>
                         <label className="relative inline-flex items-center cursor-pointer">
                            <input
                                type="checkbox"
                                id="proactive-notifications"
                                checked={localSettings.notificationSystem.proactive}
                                onChange={(e) => handleUpdate('notificationSystem', 'proactive', e.target.checked)}
                                disabled={!localSettings.notificationSystem.isActive}
                                className="sr-only peer"
                            />
                             <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full dark:bg-gray-600 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-500 peer-checked:bg-blue-600"></div>
                        </label>
                    </div>
                </div>
            </div>
             <div className="p-4 bg-gray-800/70 backdrop-blur-sm rounded-lg shadow-md">
                <div className="flex justify-between items-center mb-4">
                    <h4 className="font-bold text-lg">AI Supervisor System</h4>
                    {renderToggle('supervisorSystem')}
                </div>
                 <div className={`space-y-2 ${!localSettings.supervisorSystem.isActive ? 'opacity-50' : ''}`}>
                    <label className="text-sm font-medium">Monitoring Level</label>
                    <select
                        value={localSettings.supervisorSystem.monitoringLevel}
                        onChange={(e) => handleUpdate('supervisorSystem', 'monitoringLevel', e.target.value as 'basic' | 'advanced')}
                        disabled={!localSettings.supervisorSystem.isActive}
                        className="w-full p-2 bg-gray-700 rounded-md"
                    >
                        <option value="basic">Basic</option>
                        <option value="advanced">Advanced</option>
                    </select>
                </div>
            </div>

            <button onClick={() => onUpdate(localSettings)} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded-lg transition">Save AI Settings</button>
        </div>
    )
}

// --- MAIN COMPONENT ---
interface AdminDashboardProps {
  user: User;
  allUsers: User[];
  promotions: Promotion[];
  requests: (PurchaseRequest | DiamondRedemption)[];
  games: Game[];
  storeItems: StoreItem[];
  appSettings: AppSettings;
  aiSystemSettings: AISystemSettings;
  onLogout: () => void;
  onReviewRequest: (id: string, status: RequestStatus, reason?: string) => void;
  onSendAdminMessage: (recipientId: string, text: string, photoUrl?: string) => void;
  onUpdateAISettings: (settings: AISystemSettings) => void;
  onSetGames: (games: Game[]) => void;
  onSetStoreItems: (items: StoreItem[]) => void;
  onSetAppSettings: (settings: AppSettings) => void;
  addNotification: (message: string, type: NotificationType) => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = (props) => {
    const { user, onLogout, promotions, requests, games, storeItems, appSettings, aiSystemSettings, onUpdateAISettings, onSendAdminMessage, addNotification, onSetGames, onSetStoreItems, onSetAppSettings, onReviewRequest } = props;
    const [view, setView] = useState<AdminView>('requests');
    const [isImageModalOpen, setIsImageModalOpen] = useState<string | null>(null);
    const [isMessageModalOpen, setIsMessageModalOpen] = useState(false);
    const [rejectionInfo, setRejectionInfo] = useState<{ id: string, reason: string } | null>(null);
    
    const [recipient, setRecipient] = useState('');
    const [messageText, setMessageText] = useState('');
    const [messagePhoto, setMessagePhoto] = useState<File | null>(null);

    const [requestFilter, setRequestFilter] = useState<RequestStatus | 'ALL'>(RequestStatus.PENDING);

    const allRequests = useMemo(() => [...promotions, ...requests], [promotions, requests]);
    
    const filteredRequests = useMemo(() => {
        const sorted = allRequests.slice().sort((a, b) => {
            const statusOrder = { [RequestStatus.PENDING]: 0, [RequestStatus.APPROVED]: 1, [RequestStatus.REJECTED]: 2 };
            return statusOrder[a.status] - statusOrder[b.status];
        });

        if (requestFilter === 'ALL') return sorted;
        return sorted.filter(r => r.status === requestFilter);
    }, [allRequests, requestFilter]);


    const totalRevenue = useMemo(() => {
        return promotions.reduce((sum, promo) => sum + (promo.details.totalCost || 0), 0);
    }, [promotions]);

    const handleReview = (id: string, status: RequestStatus) => {
        const request = allRequests.find(r => r.id === id);
        if (status === RequestStatus.REJECTED && request && 'postUrl' in request.details) {
            setRejectionInfo({ id, reason: '' });
        } else {
            onReviewRequest(id, status);
        }
    };

    const handleConfirmRejection = () => {
        if (rejectionInfo && rejectionInfo.reason.trim()) {
            onReviewRequest(rejectionInfo.id, RequestStatus.REJECTED, rejectionInfo.reason);
            setRejectionInfo(null);
        } else {
            addNotification("A reason is required to reject a promotion.", "error");
        }
    };
    
    const handleSendMessage = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!recipient || !messageText) {
            addNotification('Please select a user and write a message.', 'error');
            return;
        }
        let photoUrl: string | undefined;
        if (messagePhoto) {
            photoUrl = await fileToBase64(messagePhoto);
        }
        onSendAdminMessage(recipient, messageText, photoUrl);
        setIsMessageModalOpen(false);
        setMessageText('');
        setMessagePhoto(null);
    };

    const NavButton: React.FC<{ viewName: AdminView; icon: React.ReactElement<{ className?: string }>; label: string; }> = ({ viewName, icon, label }) => (
        <button
            onClick={() => setView(viewName)}
            aria-label={label}
            className={`flex flex-col items-center justify-center space-y-1 w-14 h-14 sm:w-16 rounded-lg transition-colors duration-200 has-tooltip ${view === viewName ? 'bg-purple-900/50 text-purple-400' : 'text-gray-400 hover:bg-gray-800/70'}`}
        >
            {React.cloneElement(icon, { className: "w-5 h-5 sm:w-6 sm:h-6" })}
            <span className="text-[10px] font-bold" aria-hidden="true">{label}</span>
            <div className="tooltip tooltip-bottom" role="tooltip">{label}</div>
        </button>
    );

    const renderView = () => {
        switch(view) {
            case 'requests': return (
                <div className="animate-fade-in">
                    <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
                        <h3 className="text-xl font-bold">Manage Requests</h3>
                        <div className="flex flex-wrap gap-2">
                            {/* FIX: Use RequestStatus enum members directly to resolve TypeScript error */}
                            {(Object.values(RequestStatus).concat('ALL' as any)).map(status => (
                                <button 
                                    key={status}
                                    onClick={() => setRequestFilter(status)}
                                    className={`px-3 py-1 text-sm font-semibold rounded-full transition ${requestFilter === status ? 'bg-blue-600 text-white' : 'bg-gray-700 hover:bg-gray-600'}`}
                                >
                                    {status.charAt(0) + status.slice(1).toLowerCase()}
                                </button>
                            ))}
                        </div>
                    </div>
                    <RequestTable requests={filteredRequests} onReview={handleReview} onImageView={setIsImageModalOpen} />
                </div>
            );
            case 'manage-games': return <ManageGamesView games={games} onSetGames={onSetGames} addNotification={addNotification} />;
            case 'manage-store': return <ManageStoreView storeItems={storeItems} onSetStoreItems={onSetStoreItems} appSettings={appSettings} onSetAppSettings={onSetAppSettings} addNotification={addNotification} />;
            case 'ai-systems': return <ManageAISystems settings={aiSystemSettings} onUpdate={onUpdateAISettings} />;
            default: return <div className="p-8 bg-gray-800/70 backdrop-blur-sm rounded-lg shadow-md"><p>This section is under construction.</p></div>;
        }
    }

    return (
        <div className="min-h-screen text-gray-200">
            {isImageModalOpen && (
                <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center" onClick={() => setIsImageModalOpen(null)}>
                    <img src={isImageModalOpen} alt="Proof" className="max-w-4xl max-h-[90vh] object-contain" />
                </div>
            )}
            {rejectionInfo && (
                <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center animate-fade-in">
                    <div className="bg-gray-800/80 backdrop-blur-sm p-6 rounded-lg w-full max-w-md m-4 animate-slide-in-up">
                        <h3 className="text-xl font-bold mb-4">Reason for Rejection</h3>
                        <textarea
                            value={rejectionInfo.reason}
                            onChange={e => setRejectionInfo(prev => prev ? { ...prev, reason: e.target.value } : null)}
                            placeholder="Provide feedback to the user..."
                            className="w-full p-2 bg-gray-700 rounded-md resize-none"
                            rows={4}
                        />
                        <div className="flex justify-end space-x-2 mt-4">
                            <button onClick={() => setRejectionInfo(null)} className="px-4 py-2 rounded-lg bg-gray-600">Cancel</button>
                            <button onClick={handleConfirmRejection} className="px-4 py-2 rounded-lg bg-red-600 text-white">Confirm Rejection</button>
                        </div>
                    </div>
                </div>
            )}
            {isMessageModalOpen && (
                <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center">
                    <div className="bg-gray-800/80 backdrop-blur-sm p-6 rounded-lg w-full max-w-md">
                        <h3 className="text-xl font-bold mb-4">Send Message to User</h3>
                        <form onSubmit={handleSendMessage} className="space-y-4">
                            <select value={recipient} onChange={e => setRecipient(e.target.value)} className="w-full p-2 bg-gray-700 rounded-md">
                                <option value="">Select a user...</option>
                                {props.allUsers.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                            </select>
                            <div className="relative">
                                <textarea 
                                  value={messageText} 
                                  onChange={e => setMessageText(e.target.value)} 
                                  placeholder="Your message..." 
                                  className="w-full p-2 bg-gray-700 rounded-md resize-none pr-16" 
                                  rows={4}
                                  maxLength={500}
                                ></textarea>
                                <div className="absolute bottom-2 right-2 text-xs text-gray-500">
                                    {messageText.length} / 500
                                </div>
                            </div>
                             <input type="file" accept="image/*" onChange={e => setMessagePhoto(e.target.files ? e.target.files[0] : null)} className="w-full text-sm file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-900/50 file:text-blue-300 hover:file:bg-blue-900" />
                            <div className="flex justify-end space-x-2">
                                <button type="button" onClick={() => setIsMessageModalOpen(false)} className="px-4 py-2 rounded-lg bg-gray-600">Cancel</button>
                                <button type="submit" className="px-4 py-2 rounded-lg bg-blue-600 text-white">Send</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            <header className="fixed top-0 left-0 right-0 bg-gray-800/80 backdrop-blur-sm shadow-md z-40">
                <div className="flex items-center justify-between h-14 px-2 sm:px-4">
                    <div className="flex items-center space-x-2 bg-gray-700/70 px-2 py-1 rounded-full">
                       <div className="flex items-center space-x-1">
                           <CoinIcon className="w-4 h-4 text-green-400" />
                           <span className="font-semibold text-sm text-green-400">{totalRevenue.toFixed(2)}</span>
                           <span className="text-[10px] text-gray-400">Revenue</span>
                       </div>
                    </div>
                    <div className="flex items-center space-x-1 md:space-x-2">
                        <span className="font-semibold text-sm hidden sm:inline">Welcome, {user.name}</span>
                        <button onClick={onLogout} className="p-1.5 rounded-full hover:bg-gray-700/70">
                            <LogoutIcon className="w-5 h-5 text-red-500" />
                        </button>
                    </div>
                </div>
                <nav className="h-16 flex justify-center items-center border-t border-gray-700">
                    <div className="flex space-x-2">
                        <NavButton viewName="requests" icon={<RocketIcon />} label={`Requests (${filteredRequests.filter(r => r.status === 'PENDING').length})`} />
                        <NavButton viewName="manage-games" icon={<GamepadIcon />} label="Games" />
                        <NavButton viewName="manage-store" icon={<StoreIcon />} label="Store" />
                        <button
                          onClick={() => setIsMessageModalOpen(true)}
                          aria-label="Send Message"
                          className={`flex flex-col items-center justify-center space-y-1 w-14 h-14 sm:w-16 rounded-lg transition-colors duration-200 has-tooltip text-gray-400 hover:bg-gray-800/70`}
                        >
                            <EnvelopeIcon className="w-5 h-5 sm:w-6 sm:h-6" />
                            <span className="text-[10px] font-bold" aria-hidden="true">Messages</span>
                            <div className="tooltip tooltip-bottom" role="tooltip">Send Message</div>
                        </button>
                        <NavButton viewName="ai-systems" icon={<SparklesIcon />} label="AI Systems" />
                    </div>
                </nav>
            </header>

            <main className="flex-1 p-4 pt-32">
                {renderView()}
            </main>
        </div>
    );
};

export default AdminDashboard;