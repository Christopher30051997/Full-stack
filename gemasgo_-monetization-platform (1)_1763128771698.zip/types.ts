export enum UserRole {
  USER = 'USER',
  ADMIN = 'ADMIN',
}

export interface User {
  id: string;
  _id?: string;
  name: string;
  email?: string;
  role: UserRole;
  gemasGo: number;
  lives: number;
  favoriteGameIds: string[];
  isNewUser?: boolean;
  description?: string;
  isProfilePublic?: boolean;
  gameProgress?: { [gameId: string]: any };
  lastLifeRegenTimestamp?: number;
  createdAt?: string;
  updatedAt?: string;
}

export interface Game {
    id: string;
    _id?: string;
    name: string;
    description: string;
    genre: string;
    isActive: boolean;
    supportsSave?: boolean;
    imageUrl?: string;
    gameFileName?: string;
    releaseDate?: string;
    developer?: string;
    publisher?: string;
    createdAt?: string;
    updatedAt?: string;
}

export enum RequestStatus {
    PENDING = 'PENDING',
    APPROVED = 'APPROVED',
    REJECTED = 'REJECTED',
}

export enum TransactionType {
    PURCHASE = 'Purchase',
    REDEMPTION = 'Redemption',
    PROMOTION = 'Promotion',
}

export interface AIReview {
    status: 'Pending' | 'Approved' | 'Flagged';
    reason: string;
}

export interface Transaction {
    id: string;
    _id?: string;
    userId: string;
    userName: string;
    type: TransactionType;
    status: RequestStatus;
    details: {
        // Purchase
        amountGemas?: number;
        amountUSD?: number;
        paymentProofUrl?: string;
        // Redemption
        diamondAmount?: 100 | 465;
        gemasGoCost?: number;
        ffUserId?: string;
        // Promotion
        socialMedia?: 'Facebook' | 'YouTube' | 'TikTok';
        postUrl?: string;
        duration?: number;
        views?: number;
        likes?: number;
        comments?: number;
        totalCost?: number;
    };
    aiReview?: AIReview;
    createdAt?: string;
    updatedAt?: string;
}

export type AnyRequest = Transaction;

// FIX: Exported missing transaction types as aliases of the main Transaction type.
export type Promotion = Transaction;
export type PurchaseRequest = Transaction;
export type DiamondRedemption = Transaction;

export interface AdminMessage {
  id: string;
  _id?: string;
  sender?: 'admin';
  recipientId: string;
  text: string;
  photoUrl?: string;
  timestamp: Date;
  read: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export type GeminiToolView = 'grounded-search' | 'fast-chat';
export type NotificationType = 'success' | 'info' | 'error';
export interface AppNotification {
  id: number;
  message: string;
  type: NotificationType;
}

export interface StoreItem {
  id: string;
  _id?: string;
  name: string;
  description: string;
  cost: number;
  type: 'lives' | 'gemas' | 'diamond-pack';
  amount: number;
  isActive: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface AppSettings {
    livesCost: number;
    cryptoAddress: string;
    cryptoCurrency: string;
    lifeRegenEnabled: boolean;
    lifeRegenMinutes: number;
}

// FIX: Added and exported AppState type for use in App.tsx state.
export interface AppState {
    games: Game[],
    promotions: Promotion[],
    adminMessages: AdminMessage[],
    appSettings: AppSettings | null,
}

export interface AISystemSettings {
    adRevenueSplit: { isActive: boolean; userPercentage: number; };
    antiFraud: { isActive: boolean; enablePromotionValidation: boolean; sensitivity: 'low' | 'medium' | 'high'; ipWhitelist?: string[]; };
    notificationSystem: { isActive: boolean; proactive: boolean; };
    supervisorSystem: { isActive: boolean; monitoringLevel: 'basic' | 'advanced'; };
    transactionMonitoring: { isActive: boolean; riskThresholds: { purchase: number; redemption: number; }; autoBlock: boolean; };
}