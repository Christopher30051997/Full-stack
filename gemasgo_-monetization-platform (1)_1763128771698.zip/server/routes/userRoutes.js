const express = require("express");
const router = express.Router();
const { getInitialData, updateUser, toggleFavoriteGame, markMessagesAsRead } = require("../controllers/userController");
const { protect } = require('../middleware/authMiddleware');

router.use(protect);

router.get("/initial-data", getInitialData);
router.put("/", updateUser);
router.put("/favorites/:gameId", toggleFavoriteGame);
router.post("/messages/read", markMessagesAsRead);

module.exports = router;
