const express = require("express");
const router = express.Router();
const { 
    getAdminDashboardData, 
    reviewTransaction, 
    sendAdminMessage, 
    updateAppSettings, 
    updateAiSettings, 
    updateUserByAdmin, 
    deleteUserByAdmin 
} = require("../controllers/adminController");
const { protect } = require('../middleware/authMiddleware');
const { admin } = require('../middleware/adminMiddleware');

router.use(protect, admin);

router.get("/dashboard-data", getAdminDashboardData);
router.put("/transactions/:id/review", reviewTransaction);
router.post("/messages", sendAdminMessage);
router.put("/settings/app", updateAppSettings);
router.put("/settings/ai", updateAiSettings);
router.put("/users/:id", updateUserByAdmin);
router.delete("/users/:id", deleteUserByAdmin);

module.exports = router;
