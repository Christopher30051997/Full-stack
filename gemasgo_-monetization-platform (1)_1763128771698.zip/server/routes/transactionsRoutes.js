const express = require("express");
const router = express.Router();
const { createPromotion, createPurchaseRequest, createDiamondRedemption, getTransactionHistory } = require("../controllers/transactionsController");
const { protect } = require('../middleware/authMiddleware');

router.use(protect);

router.post("/promotion", createPromotion);
router.post("/purchase", createPurchaseRequest);
router.post("/redemption", createDiamondRedemption);
router.get("/history", getTransactionHistory);

module.exports = router;
