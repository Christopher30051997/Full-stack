const express = require("express");
const router = express.Router();
const { getShopItems, createShopItem, updateShopItem, deleteShopItem } = require("../controllers/shopController");
const { protect } = require('../middleware/authMiddleware');
const { admin } = require('../middleware/adminMiddleware');

// Public route
router.get("/", protect, getShopItems);

// Admin routes
router.post("/", protect, admin, createShopItem);
router.put("/:id", protect, admin, updateShopItem);
router.delete("/:id", protect, admin, deleteShopItem);

module.exports = router;
