const express = require("express");
const router = express.Router();
const { getAllGames, createGame, updateGame, deleteGame } = require("../controllers/gamesController");
const { protect } = require('../middleware/authMiddleware');
const { admin } = require('../middleware/adminMiddleware');

// Public route
router.get("/", protect, getAllGames);

// Admin routes
router.post("/", protect, admin, createGame);
router.put("/:id", protect, admin, updateGame);
router.delete("/:id", protect, admin, deleteGame);

module.exports = router;
