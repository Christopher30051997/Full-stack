const errorMiddleware = (err, req, res, next) => {
    console.error('API ERROR:', err.stack);

    let statusCode = res.statusCode === 200 ? 500 : res.statusCode;
    let message = err.message || 'Internal Server Error';

    // Mongoose specific errors
    if (err.name === 'CastError' && err.kind === 'ObjectId') {
        statusCode = 404;
        message = 'Resource not found';
    }
    if (err.code === 11000) {
        statusCode = 400;
        message = 'Duplicate field value entered';
    }
    if (err.name === 'ValidationError') {
        statusCode = 400;
        message = Object.values(err.errors).map(val => val.message).join(', ');
    }
    
    res.status(statusCode).json({ message });
};

module.exports = errorMiddleware;
