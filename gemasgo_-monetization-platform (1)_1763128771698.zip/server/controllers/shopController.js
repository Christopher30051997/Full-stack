const ShopItem = require("../models/ShopItem");

exports.getShopItems = async (req, res, next) => {
  try {
    const items = await ShopItem.find({ isActive: true }).sort({ name: 1 });
    res.status(200).json(items);
  } catch (err) {
    next(err);
  }
};

// --- ADMIN ---
exports.createShopItem = async (req, res, next) => {
    try {
        const item = await ShopItem.create(req.body);
        res.status(201).json(item);
    } catch(err) { next(err); }
};
exports.updateShopItem = async (req, res, next) => {
    try {
        const item = await ShopItem.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
        if (!item) return res.status(404).json({ message: "Shop item not found" });
        res.status(200).json(item);
    } catch(err) { next(err); }
};
exports.deleteShopItem = async (req, res, next) => {
    try {
        const item = await ShopItem.findByIdAndDelete(req.params.id);
        if (!item) return res.status(404).json({ message: "Shop item not found" });
        res.status(200).json({ success: true });
    } catch(err) { next(err); }
};
