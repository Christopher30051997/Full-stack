const User = require("../models/User");
const Transaction = require("../models/Transaction");
const SubmittedProof = require("../models/SubmittedProof");

exports.createPromotion = async (req, res, next) => {
    try {
        const user = req.user;
        const { totalCost, ...details } = req.body;
        if (user.gemasGo < totalCost) {
            return res.status(400).json({ message: "Insufficient GemasGo" });
        }
        details.totalCost = totalCost;
        const transaction = await Transaction.create({ userId: user._id, userName: user.name, type: 'Promotion', details });
        user.gemasGo -= totalCost;
        await user.save();
        res.status(201).json(transaction);
    } catch (err) {
        next(err);
    }
};

exports.createPurchaseRequest = async (req, res, next) => {
    try {
        const { proofKey, ...details } = req.body;
        const existingProof = await SubmittedProof.findOne({ key: proofKey });
        if (existingProof) {
            return res.status(400).json({ message: "This payment proof has already been submitted." });
        }
        const transaction = await Transaction.create({ userId: req.user._id, userName: req.user.name, type: 'Purchase', details });
        await SubmittedProof.create({ key: proofKey });
        res.status(201).json(transaction);
    } catch (err) {
        next(err);
    }
};

exports.createDiamondRedemption = async (req, res, next) => {
    try {
        const user = req.user;
        const { gemasGoCost, ...details } = req.body;
        if (user.gemasGo < gemasGoCost) {
            return res.status(400).json({ message: "Insufficient GemasGo" });
        }
        details.gemasGoCost = gemasGoCost;
        const transaction = await Transaction.create({ userId: user._id, userName: user.name, type: 'Redemption', details });
        user.gemasGo -= gemasGoCost;
        await user.save();
        res.status(201).json(transaction);
    } catch (err) {
        next(err);
    }
};

exports.getTransactionHistory = async (req, res, next) => {
    try {
        const transactions = await Transaction.find({ userId: req.user._id, type: 'Promotion' }).sort({ createdAt: -1 });
        res.status(200).json(transactions);
    } catch (err) {
        next(err);
    }
};
