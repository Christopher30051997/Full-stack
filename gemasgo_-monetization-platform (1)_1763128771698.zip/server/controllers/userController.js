const User = require("../models/User");
const Game = require("../models/Game");
const Transaction = require("../models/Transaction");
const AdminMessage = require("../models/AdminMessage");
const Setting = require("../models/Setting");

exports.getInitialData = async (req, res, next) => {
    try {
        const userId = req.user._id;
        const appSettings = await Setting.getSettings('appSettings');
        await req.user.regenerateLives(appSettings);
        
        const [games, promotions, adminMessages] = await Promise.all([
            Game.find({ isActive: true }),
            Transaction.find({ type: 'Promotion', status: 'APPROVED' }).sort({ createdAt: -1 }).limit(20),
            AdminMessage.find({ recipientId: userId }).sort({ createdAt: -1 }),
        ]);
        res.status(200).json({ games, promotions, adminMessages, appSettings });
    } catch (err) {
        next(err);
    }
};

exports.updateUser = async (req, res, next) => {
    try {
        const { lives, gemasGo, gameProgress, isNewUser } = req.body;
        const user = await User.findById(req.user.id);
        if (!user) return res.status(404).json({ message: "User not found" });

        if (lives !== undefined) {
            if (lives < user.lives) user.lastLifeRegenTimestamp = Date.now();
            user.lives = lives;
        }
        if (gemasGo !== undefined) user.gemasGo = gemasGo;
        if (gameProgress !== undefined) user.gameProgress = gameProgress;
        if (isNewUser !== undefined) user.isNewUser = isNewUser;

        await user.save();
        res.status(200).json(user);
    } catch (err) {
        next(err);
    }
};

exports.toggleFavoriteGame = async (req, res, next) => {
    try {
        const { gameId } = req.params;
        const user = await User.findById(req.user.id);
        if (!user) return res.status(404).json({ message: "User not found" });

        const index = user.favoriteGameIds.indexOf(gameId);
        if (index > -1) user.favoriteGameIds.splice(index, 1);
        else user.favoriteGameIds.push(gameId);

        await user.save();
        res.status(200).json(user);
    } catch (err) {
        next(err);
    }
};

exports.markMessagesAsRead = async (req, res, next) => {
    try {
        await AdminMessage.updateMany({ recipientId: req.user._id, read: false }, { read: true });
        res.status(200).json({ success: true });
    } catch (err) {
        next(err);
    }
};
