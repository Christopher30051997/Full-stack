const User = require("../models/User");
const jwt = require("jsonwebtoken");
const Setting = require("../models/Setting");

const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: "30d" });
};

const sendTokenResponse = (user, statusCode, res) => {
  const token = generateToken(user._id);
  const userObject = user.toObject();
  delete userObject.password;
  res.status(statusCode).json({ ...userObject, token });
};

exports.register = async (req, res, next) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !password) return res.status(400).json({ message: "Please provide name and password" });
    if (name.toLowerCase() === 'admin') return res.status(400).json({ message: "This username is reserved." });
    
    const userExists = await User.findOne({ name });
    if (userExists) return res.status(400).json({ message: "User with that name already exists" });

    const user = await User.create({ name, email, password });
    sendTokenResponse(user, 201, res);
  } catch (err) {
    next(err);
  }
};

exports.login = async (req, res, next) => {
  try {
    const { name, password, email } = req.body;
    if (!name || !password) return res.status(400).json({ message: "Please provide name and password" });

    const user = await User.findOne({ name }).select('+password');

    if (!user) {
      if (name.toLowerCase() === 'admin') return res.status(401).json({ message: "Invalid credentials" });
      const newUser = await User.create({ name, password, email });
      return sendTokenResponse(newUser, 201, res);
    }

    const isMatch = await user.matchPassword(password);
    if (!isMatch) return res.status(401).json({ message: "Invalid credentials" });
    sendTokenResponse(user, 200, res);
  } catch (err) {
    next(err);
  }
};

exports.getMe = async (req, res, next) => {
    try {
        const appSettings = await Setting.getSettings('appSettings');
        await req.user.regenerateLives(appSettings);
        res.status(200).json(req.user);
    } catch (err) {
        next(err);
    }
};
