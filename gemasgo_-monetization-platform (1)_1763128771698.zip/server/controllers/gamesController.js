const Game = require("../models/Game");

exports.getAllGames = async (req, res, next) => {
  try {
    const games = await Game.find({ isActive: true }).sort({ name: 1 });
    res.status(200).json(games);
  } catch (err) {
    next(err);
  }
};

// --- ADMIN ---
exports.createGame = async (req, res, next) => {
    try {
        const game = await Game.create(req.body);
        res.status(201).json(game);
    } catch(err) { next(err); }
};
exports.updateGame = async (req, res, next) => {
    try {
        const game = await Game.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
        if (!game) return res.status(404).json({ message: "Game not found" });
        res.status(200).json(game);
    } catch(err) { next(err); }
};
exports.deleteGame = async (req, res, next) => {
    try {
        const game = await Game.findByIdAndDelete(req.params.id);
        if (!game) return res.status(404).json({ message: "Game not found" });
        res.status(200).json({ success: true });
    } catch(err) { next(err); }
};
