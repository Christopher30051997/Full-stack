const User = require("../models/User");
const Game = require("../models/Game");
const ShopItem = require("../models/ShopItem");
const Setting = require("../models/Setting");
const Transaction = require("../models/Transaction");
const AdminMessage = require("../models/AdminMessage");

exports.getAdminDashboardData = async (req, res, next) => {
    try {
        const [
            users,
            transactions,
            games,
            storeItems,
            appSettings,
            aiSystemSettings
        ] = await Promise.all([
            User.find({}).select("-password"),
            Transaction.find({}).sort({ createdAt: -1 }),
            Game.find({}).sort({ name: 1 }),
            ShopItem.find({}).sort({ name: 1 }),
            Setting.getSettings('appSettings'),
            Setting.getSettings('aiSystemSettings')
        ]);
        res.status(200).json({
            users, transactions, games, storeItems, appSettings, aiSystemSettings
        });
    } catch (err) {
        next(err);
    }
};

exports.reviewTransaction = async (req, res, next) => {
    try {
        const { id } = req.params;
        const { status, reason } = req.body;
        const transaction = await Transaction.findById(id);
        if (!transaction) return res.status(404).json({ message: "Transaction not found" });

        transaction.status = status;
        const user = await User.findById(transaction.userId);
        if (!user) return res.status(404).json({ message: "Associated user not found" });

        if (status === 'APPROVED' && transaction.type === 'Purchase') {
            user.gemasGo += transaction.details.amountGemas;
            await user.save();
            await AdminMessage.create({
                recipientId: user._id,
                text: `Your purchase of ${transaction.details.amountGemas} GemasGo has been approved.`,
            });
        } else if (status === 'REJECTED') {
            if (transaction.type === 'Promotion' || transaction.type === 'Redemption') {
                const costToRefund = transaction.details.totalCost || transaction.details.gemasGoCost;
                if (costToRefund) {
                    user.gemasGo += costToRefund;
                    await user.save();
                }
            }
            await AdminMessage.create({
                recipientId: user._id,
                text: `Your ${transaction.type.toLowerCase()} request was rejected. ${reason ? `Reason: ${reason}` : ''}`,
            });
        }

        await transaction.save();
        res.status(200).json(transaction);
    } catch (err) {
        next(err);
    }
};

exports.sendAdminMessage = async (req, res, next) => {
    try {
        const { recipientId, text, photoUrl } = req.body;
        const message = await AdminMessage.create({ recipientId, text, photoUrl });
        res.status(201).json(message);
    } catch (err) {
        next(err);
    }
};

exports.updateAppSettings = async (req, res, next) => {
    try {
        const settings = await Setting.findOneAndUpdate({ key: 'appSettings' }, { value: req.body }, { new: true, upsert: true });
        res.status(200).json(settings.value);
    } catch (err) {
        next(err);
    }
};

exports.updateAiSettings = async (req, res, next) => {
    try {
        const settings = await Setting.findOneAndUpdate({ key: 'aiSystemSettings' }, { value: req.body }, { new: true, upsert: true });
        res.status(200).json(settings.value);
    } catch (err) {
        next(err);
    }
};

exports.updateUserByAdmin = async (req, res, next) => {
    try {
        const { role, ...updates } = req.body;
        if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
            return res.status(400).json({ message: 'Invalid user ID' });
        }
        
        const user = await User.findById(req.params.id);
        if (!user) return res.status(404).json({ message: "User not found" });

        // Apply general updates
        Object.assign(user, updates);

        // Apply role update if provided and different
        if (role && user.role !== role) {
            user.role = role;
        }

        const updatedUser = await user.save();
        res.status(200).json(updatedUser);
    } catch(err) { next(err); }
};

exports.deleteUserByAdmin = async (req, res, next) => {
     try {
        const user = await User.findByIdAndDelete(req.params.id);
        if (!user) return res.status(404).json({ message: "User not found" });
        await Transaction.deleteMany({ userId: req.params.id });
        await AdminMessage.deleteMany({ recipientId: req.params.id });
        res.status(200).json({ success: true });
    } catch(err) { next(err); }
};
