const mongoose = require("mongoose");

const SubmittedProofSchema = new mongoose.Schema({
    key: { type: String, required: true, unique: true },
}, { timestamps: true });

module.exports = mongoose.model("SubmittedProof", SubmittedProofSchema);
