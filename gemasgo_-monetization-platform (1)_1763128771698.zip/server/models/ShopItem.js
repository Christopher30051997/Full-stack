const mongoose = require("mongoose");

const ShopItemSchema = new mongoose.Schema({
  name: { type: String, required: true },
  description: { type: String, required: true },
  cost: { type: Number, required: true },
  type: { type: String, enum: ['lives', 'gemas', 'diamond-pack'], required: true },
  amount: { type: Number, required: true },
  isActive: { type: Boolean, default: true }
}, { 
    timestamps: true,
    toJSON: { virtuals: true, transform(doc, ret) { ret.id = ret._id; delete ret._id; delete ret.__v; } },
    toObject: { virtuals: true, transform(doc, ret) { ret.id = ret._id; delete ret._id; delete ret.__v; } }
});

module.exports = mongoose.model("ShopItem", ShopItemSchema);
