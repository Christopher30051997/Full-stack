const mongoose = require("mongoose");

const SettingSchema = new mongoose.Schema({
    key: { type: String, required: true, unique: true },
    value: { type: mongoose.Schema.Types.Mixed, required: true }
});

SettingSchema.statics.getSettings = async function(key, defaultValue) {
    let setting = await this.findOne({ key });
    if (!setting && defaultValue) {
        setting = await this.create({ key, value: defaultValue });
    }
    return setting ? setting.value : defaultValue;
};

module.exports = mongoose.model("Setting", SettingSchema);
