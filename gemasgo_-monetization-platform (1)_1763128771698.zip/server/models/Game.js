const mongoose = require("mongoose");

const GameSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  description: { type: String, required: true },
  genre: { type: String, required: true },
  isActive: { type: Boolean, default: true },
  supportsSave: { type: Boolean, default: false },
  imageUrl: { type: String },
  gameFileName: { type: String },
  releaseDate: { type: Date },
  developer: { type: String },
  publisher: { type: String },
}, { 
    timestamps: true,
    toJSON: { virtuals: true, transform(doc, ret) { ret.id = ret._id; delete ret._id; delete ret.__v; } },
    toObject: { virtuals: true, transform(doc, ret) { ret.id = ret._id; delete ret._id; delete ret.__v; } }
});

module.exports = mongoose.model("Game", GameSchema);
