const mongoose = require("mongoose");

const AIReviewSchema = new mongoose.Schema({
    status: { type: String, enum: ['Pending', 'Approved', 'Flagged'], default: 'Pending' },
    reason: { type: String, default: '' }
}, { _id: false });

const TransactionSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    userName: { type: String, required: true },
    type: {
        type: String,
        enum: ['Purchase', 'Redemption', 'Promotion'],
        required: true
    },
    status: {
        type: String,
        enum: ['PENDING', 'APPROVED', 'REJECTED'],
        default: 'PENDING'
    },
    details: {
        type: mongoose.Schema.Types.Mixed,
        required: true
    },
    aiReview: {
        type: AIReviewSchema,
        required: false
    }
}, {
    timestamps: true,
    toJSON: { virtuals: true, transform: (doc, ret) => { ret.id = ret._id; delete ret._id; delete ret.__v; } },
    toObject: { virtuals: true, transform: (doc, ret) => { ret.id = ret._id; delete ret._id; delete ret.__v; } }
});

module.exports = mongoose.model("Transaction", TransactionSchema);
