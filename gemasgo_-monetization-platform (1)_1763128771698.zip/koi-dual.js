const canvas = document.getElementById('canvas-koi');
const ctx = canvas.getContext('2d');
canvas.width = innerWidth;
canvas.height = innerHeight;

const colors1 = ['#ffffff', '#ff4500', '#ffb347', '#ff0000', '#ffd700'];
const colors2 = ['#ffffff', '#00bfff', '#1e90ff', '#000000', '#87cefa'];
const fishA = [];
const fishB = [];
const bubbles = [];

let angle = 0;

// Curva del pez (forma 3D simulada)
function fishShape(t) {
  const x = Math.sin(t) * 180 * Math.cos(t / 2);
  const y = Math.sin(t * 2) * 70 * Math.sin(t / 3);
  return { x, y };
}

class Particle {
  constructor(x, y, color, reverse = false) {
    this.baseX = x;
    this.baseY = y;
    this.reverse = reverse;
    this.x = x + canvas.width / 2;
    this.y = y + canvas.height / 2;
    this.z = Math.random() * 200 - 100;
    this.color = color;
    this.size = Math.random() * 2 + 0.8;
  }

  update() {
    const swim = Math.sin(angle * 1.5 + this.baseX * 0.05) * 10 * (this.reverse ? -1 : 1);
    this.z += this.reverse ? -0.6 : 0.6;
    if (this.z > 200) this.z = -200;
    if (this.z < -200) this.z = 200;

    const scale = 300 / (300 + this.z);
    const x2d = (this.baseX + swim) * scale + canvas.width / 2;
    const y2d = this.baseY * scale + canvas.height / 2 + (this.reverse ? 100 : -100);

    ctx.beginPath();
    ctx.arc(x2d, y2d, this.size * scale, 0, Math.PI * 2);
    const glow = `hsla(${Math.random() * 30 + 20},100%,60%,0.8)`;
    ctx.fillStyle = Math.random() > 0.97 ? glow : this.color;
    ctx.shadowBlur = 10;
    ctx.shadowColor = ctx.fillStyle;
    ctx.fill();
  }
}

// Burbujas de fondo
class Bubble {
  constructor() {
    this.x = Math.random() * canvas.width;
    this.y = canvas.height + 10;
    this.size = Math.random() * 3 + 1;
    this.speed = Math.random() * 1.5 + 0.5;
    this.alpha = Math.random() * 0.4 + 0.2;
  }

  update() {
    this.y -= this.speed;
    if (this.y < -10) {
      this.y = canvas.height + 10;
      this.x = Math.random() * canvas.width;
    }
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(255,255,255,${this.alpha})`;
    ctx.fill();
  }
}

// Crear partículas de los dos peces
for (let i = 0; i < 1200; i++) {
  const t = Math.random() * Math.PI * 4;
  const pos = fishShape(t);
  const color1 = colors1[Math.floor(Math.random() * colors1.length)];
  const color2 = colors2[Math.floor(Math.random() * colors2.length)];
  fishA.push(new Particle(pos.x, pos.y, color1, false));
  fishB.push(new Particle(pos.x, pos.y, color2, true));
}

// Crear burbujas
for (let i = 0; i < 100; i++) bubbles.push(new Bubble());

// Animar
function animate() {
  if (!ctx) return;
  ctx.fillStyle = 'rgba(0,0,0,0.15)';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  angle += 0.01;

  bubbles.forEach(b => b.update());
  fishA.forEach(p => p.update());
  fishB.forEach(p => p.update());

  requestAnimationFrame(animate);
}

animate();

window.addEventListener('resize', () => {
  canvas.width = innerWidth;
  canvas.height = innerHeight;
});
