/**
 * A centralized logging service.
 * In a real application, this would integrate with a service like Sentry, LogRocket, etc.
 * For this demo, it logs detailed errors to the console.
 */

interface LogContext {
  [key: string]: any;
}

export const logError = (error: Error, context?: LogContext): void => {
  console.error("--- ERROR LOGGED ---");
  console.error("Message:", error.message);
  console.error("Stack:", error.stack);
  
  if (context) {
    console.error("Context:", JSON.stringify(context, null, 2));
  }
  
  console.error("--- END OF ERROR LOG ---");

  // Example of sending to a real service:
  // Sentry.withScope(scope => {
  //   scope.setExtras(context || {});
  //   Sentry.captureException(error);
  // });
};
