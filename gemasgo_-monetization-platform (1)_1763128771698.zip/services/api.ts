import { User, Game, Transaction, AppSettings, AdminMessage, AISystemSettings, StoreItem, UserRole } from '../types';

const API_BASE_URL = '/api';

const getAuthToken = () => {
    if (window.location.pathname.startsWith('/admin-console-secure-panel')) {
        return localStorage.getItem('gemasgo-adm-token');
    }
    return localStorage.getItem('gemasgo-token');
};

const request = async <T>(endpoint: string, options: RequestInit = {}): Promise<T> => {
    const token = getAuthToken();
    const headers = new Headers(options.headers);

    if (!headers.has('Content-Type') && !(options.body instanceof FormData)) {
        headers.set('Content-Type', 'application/json');
    }
    
    if (token) {
        headers.set('Authorization', `Bearer ${token}`);
    }

    const response = await fetch(`${API_BASE_URL}${endpoint}`, { ...options, headers });

    if (!response.ok) {
        const data = await response.json();
        throw new Error(data.message || 'An error occurred');
    }

    // Handle cases where the response might be empty (e.g., 204 No Content)
    const contentType = response.headers.get("content-type");
    if (contentType && contentType.indexOf("application/json") !== -1) {
        return response.json();
    } else {
        return {} as T;
    }
};

// Auth
export const login = (name: string, password: string, isRegister: boolean, email?: string): Promise<User & { token: string }> => {
    return request(isRegister ? '/auth/register' : '/auth/login', {
        method: 'POST',
        body: JSON.stringify({ name, password, email }),
    });
};
export const logout = () => {
    localStorage.removeItem('gemasgo-token');
    localStorage.removeItem('gemasgo-adm-token');
};
export const getMe = (): Promise<User> => request('/auth/me');

// User App
export const getInitialAppData = (): Promise<{ games: Game[], promotions: Transaction[], adminMessages: AdminMessage[], appSettings: AppSettings }> => request('/users/initial-data');
export const updateUser = (userId: string, updates: Partial<User>): Promise<User> => request('/users', { method: 'PUT', body: JSON.stringify(updates) });
export const toggleFavoriteGame = (gameId: string): Promise<User> => request(`/users/favorites/${gameId}`, { method: 'PUT' });
export const markMessagesAsRead = (): Promise<{ success: boolean }> => request('/users/messages/read', { method: 'POST' });

// Transactions
export const getUserPromotions = (): Promise<Transaction[]> => request('/transactions/history');
export const createPromotion = (promoData: any): Promise<Transaction> => request('/transactions/promotion', { method: 'POST', body: JSON.stringify(promoData) });
export const createPurchaseRequest = (requestData: any, proofKey: string): Promise<Transaction> => request('/transactions/purchase', { method: 'POST', body: JSON.stringify({ ...requestData, proofKey }) });
export const createDiamondRedemption = (requestData: any): Promise<Transaction> => request('/transactions/redemption', { method: 'POST', body: JSON.stringify(requestData) });

// Admin Panel
export const getAdminData = (): Promise<any> => request('/admin/dashboard-data');
export const reviewRequest = (requestId: string, status: string, reason?: string): Promise<Transaction> => request(`/admin/transactions/${requestId}/review`, { method: 'PUT', body: JSON.stringify({ status, reason }) });
export const sendAdminMessage = (recipientId: string, text: string, photoUrl?: string): Promise<AdminMessage> => request('/admin/messages', { method: 'POST', body: JSON.stringify({ recipientId, text, photoUrl }) });
export const updateAppSettings = (settings: AppSettings): Promise<AppSettings> => request('/admin/settings/app', { method: 'PUT', body: JSON.stringify(settings) });
export const updateAiSettings = (settings: AISystemSettings): Promise<AISystemSettings> => request('/admin/settings/ai', { method: 'PUT', body: JSON.stringify(settings) });

// Admin Game Management
export const createGame = (gameData: Partial<Game>): Promise<Game> => request('/games', { method: 'POST', body: JSON.stringify(gameData) });
export const updateGame = (gameId: string, gameData: Partial<Game>): Promise<Game> => request(`/games/${gameId}`, { method: 'PUT', body: JSON.stringify(gameData) });
export const deleteGame = (gameId: string): Promise<{ success: boolean }> => request(`/games/${gameId}`, { method: 'DELETE' });

// Admin Store Management
export const createStoreItem = (itemData: Partial<StoreItem>): Promise<StoreItem> => request('/shop', { method: 'POST', body: JSON.stringify(itemData) });
export const updateStoreItem = (itemId: string, itemData: Partial<StoreItem>): Promise<StoreItem> => request(`/shop/${itemId}`, { method: 'PUT', body: JSON.stringify(itemData) });
export const deleteStoreItem = (itemId: string): Promise<{ success: boolean }> => request(`/shop/${itemId}`, { method: 'DELETE' });

// Admin User Management
export const updateUserByAdmin = (userId: string, updates: Partial<User>): Promise<User> => request(`/admin/users/${userId}`, { method: 'PUT', body: JSON.stringify(updates) });
export const deleteUserByAdmin = (userId: string): Promise<{ success: boolean }> => request(`/admin/users/${userId}`, { method: 'DELETE' });
export const updateUserRole = (userId: string, role: UserRole): Promise<User> => request(`/admin/users/${userId}/role`, { method: 'PUT', body: JSON.stringify({ role }) });