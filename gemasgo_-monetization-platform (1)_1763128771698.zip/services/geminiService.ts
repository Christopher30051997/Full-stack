import { GoogleGenAI } from "@google/genai";
import { logError } from './loggingService';

const getGenAI = () => {
  if (!process.env.API_KEY) {
    const error = new Error("API_KEY environment variable not set. Please configure it to use AI features.");
    logError(error, { service: 'geminiService', function: 'getGenAI' });
    // Don't throw here, let individual functions handle it gracefully if possible
    return null;
  }
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

// --- Grounded Search ---
export const getGroundedAnswer = async (prompt: string) => {
  const ai = getGenAI();
  if (!ai) {
      throw new Error("AI Service is not configured. Missing API Key.");
  }
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    return {
      text: response.text,
      sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || [],
    };
  } catch (error) {
    logError(error, { service: 'geminiService', function: 'getGroundedAnswer', prompt });
    throw new Error('Failed to get a response from the AI. Please try again later.');
  }
};

// --- Fast, Low-Latency Chat ---
export const getFastAnswer = async (prompt: string) => {
  const ai = getGenAI();
   if (!ai) {
      throw new Error("AI Service is not configured. Missing API Key.");
  }
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-flash-latest',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    logError(error, { service: 'geminiService', function: 'getFastAnswer' });
    throw new Error('Could not connect to the chat assistant. Please check your connection.');
  }
};

// --- Complex Analysis ---
export const getProAnalysis = async (prompt: string) => {
  const ai = getGenAI();
   if (!ai) {
      throw new Error("AI Service is not configured. Missing API Key.");
  }
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-pro',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    logError(error, { service: 'geminiService', function: 'getProAnalysis' });
    throw new Error('An error occurred during the complex analysis. Please try again.');
  }
};
