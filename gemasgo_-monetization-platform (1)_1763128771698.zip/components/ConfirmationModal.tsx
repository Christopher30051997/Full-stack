import React from 'react';
import { CloseIcon } from './icons';
import Spinner from './Spinner';

interface ConfirmationModalProps {
    isOpen: boolean;
    onClose: () => void;
    onConfirm: () => void;
    title: string;
    children: React.ReactNode;
    isConfirming?: boolean;
    confirmText?: string;
    cancelText?: string;
}

const ConfirmationModal: React.FC<ConfirmationModalProps> = ({ 
    isOpen, 
    onClose, 
    onConfirm, 
    title, 
    children, 
    isConfirming = false,
    confirmText = 'Confirm',
    cancelText = 'Cancel'
}) => {
    if (!isOpen) return null;
    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center animate-fade-in" onClick={onClose}>
            <div className="bg-gray-800/80 backdrop-blur-sm rounded-xl shadow-2xl w-full max-w-md m-4 animate-slide-in-up" onClick={e => e.stopPropagation()}>
                <div className="flex justify-between items-center p-3 border-b border-gray-700">
                    <h3 className="text-lg font-bold">{title}</h3>
                    <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-700"><CloseIcon className="w-5 h-5" /></button>
                </div>
                <div className="p-4 text-sm">{children}</div>
                <div className="flex justify-end space-x-3 p-3 bg-gray-700/50 rounded-b-xl">
                    <button onClick={onClose} className="px-3 py-1.5 rounded-lg bg-gray-600 hover:bg-gray-500 font-semibold text-sm" disabled={isConfirming}>{cancelText}</button>
                    <button onClick={onConfirm} className="px-3 py-1.5 rounded-lg bg-blue-600 text-white hover:bg-blue-700 font-bold w-24 text-sm" disabled={isConfirming}>
                        {isConfirming ? <Spinner /> : confirmText}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ConfirmationModal;
