import React from 'react';
import { HeartIcon } from './icons';

interface LivesTrackerProps {
  lives: number;
  maxLives?: number;
}

const LivesTracker: React.FC<LivesTrackerProps> = ({ lives, maxLives = 5 }) => {
  return (
    <div className="flex items-center space-x-2 p-2 bg-gray-800/70 rounded-lg">
      <HeartIcon className="w-6 h-6 text-red-500" />
      <span className="font-bold text-xl text-red-400">{lives}</span>
      <span className="text-gray-400 text-sm">/ {maxLives}</span>
    </div>
  );
};

export default LivesTracker;
