import React, { useEffect } from 'react';
import { NotificationType } from '../types';
import { CloseIcon, InfoIcon, CheckCircleIcon, XCircleIcon } from './icons';

interface NotificationProps {
  message: string;
  type: NotificationType;
  onClose: () => void;
}

const notificationConfig = {
    success: {
        icon: <CheckCircleIcon className="w-6 h-6 text-green-500" />,
        style: 'bg-green-900/50 border-green-500/30 text-green-300',
    },
    info: {
        icon: <InfoIcon className="w-6 h-6 text-blue-500" />,
        style: 'bg-blue-900/50 border-blue-500/30 text-blue-300',
    },
    error: {
        icon: <XCircleIcon className="w-6 h-6 text-red-500" />,
        style: 'bg-red-900/50 border-red-500/30 text-red-300',
    },
};


const Notification: React.FC<NotificationProps> = ({ message, type, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 5000); // Auto-dismiss after 5 seconds

    return () => clearTimeout(timer);
  }, [onClose]);
  
  const { icon, style } = notificationConfig[type];

  return (
    <div className={`w-80 p-4 rounded-lg shadow-lg border flex items-start space-x-3 animate-fade-in-down ${style}`}>
        <div className="flex-shrink-0">
            {icon}
        </div>
        <div className="flex-1">
            <p className="font-semibold text-sm">{message}</p>
        </div>
        <button onClick={onClose} className="p-1 -m-1 rounded-full hover:bg-black/10 transition-colors">
            <CloseIcon className="w-4 h-4" />
        </button>
    </div>
  );
};

export default Notification;