import React, { useState, useEffect, useLayoutEffect, useRef } from 'react';
import { GamepadIcon, TvIcon, StoreIcon, RocketIcon, SparklesIcon, CloseIcon, CoinIcon, CheckCircleIcon } from './icons';

interface OnboardingGuideProps {
    onComplete: () => void;
}

type GuideStep = {
    type: 'modal' | 'highlight';
    targetId?: string;
    icon: React.ReactElement;
    title: string;
    content: string;
}

const guideSteps: GuideStep[] = [
    {
        type: 'modal',
        icon: <GamepadIcon className="w-12 h-12 text-purple-500" />,
        title: "¡Bienvenido a GemasGo!",
        content: "Esta es tu plataforma para jugar, ganar y promocionar. ¡Vamos a dar un tour rápido por las funciones principales!",
    },
    {
        type: 'highlight',
        targetId: 'user-info-header',
        icon: <CoinIcon className="w-12 h-12 text-yellow-500" />,
        title: "Tu Perfil y Saldo",
        content: "Este es tu panel de control rápido. Muestra tu nombre de usuario y, lo más importante, tu saldo de GemasGo. ¡Acumula GemasGo para gastarlas en la tienda!",
    },
    {
        type: 'highlight',
        targetId: 'nav-games',
        icon: <GamepadIcon className="w-12 h-12 text-purple-500" />,
        title: "Sección de Juegos",
        content: "Aquí es donde ocurre la diversión. Descubre y juega a todos nuestros juegos. Gasta una vida para jugar y no olvides marcar tus favoritos con la estrella para un acceso rápido.",
    },
    {
        type: 'highlight',
        targetId: 'nav-ads',
        icon: <TvIcon className="w-12 h-12 text-cyan-500" />,
        title: "Sección de Anuncios",
        content: "¿Necesitas más GemasGo? En esta sección, podrás ver anuncios para ganar recompensas. También puedes apoyar a otros usuarios viendo sus videos promocionados.",
    },
    {
        type: 'highlight',
        targetId: 'nav-store',
        icon: <StoreIcon className="w-12 h-12 text-green-500" />,
        title: "La Tienda",
        content: "¡Tu centro de compras! Usa tus GemasGo para comprar más vidas y seguir jugando, o canjéalas por premios increíbles como diamantes para Free Fire. También puedes comprar GemasGo directamente aquí.",
    },
    {
        type: 'highlight',
        targetId: 'nav-promotions',
        icon: <RocketIcon className="w-12 h-12 text-pink-500" />,
        title: "Crea Promociones",
        content: "¿Quieres que tu contenido se vuelva viral? Usa esta sección para crear campañas para tus publicaciones de Facebook, TikTok o YouTube. ¡Invierte GemasGo para conseguir más vistas!",
    },
    {
        type: 'highlight',
        targetId: 'nav-gemini',
        icon: <SparklesIcon className="w-12 h-12 text-blue-500" />,
        title: "Herramientas de IA",
        content: "Potencia tu experiencia con la IA de Gemini. Usa el 'Quick Assistant' para obtener respuestas a tus preguntas, o el 'Grounded Search' para buscar información en la web.",
    },
    {
        type: 'modal',
        icon: <CheckCircleIcon className="w-12 h-12 text-green-500" />,
        title: "¡Todo Listo!",
        content: "Ya conoces lo básico. ¡Es hora de explorar, jugar y ganar! Si en algún momento tienes dudas, recuerda que puedes contactar al asistente de IA de GemasGo en la sección 'AI Tools'.",
    }
];


const OnboardingGuide: React.FC<OnboardingGuideProps> = ({ onComplete }) => {
    const [step, setStep] = useState(0);
    const [targetRect, setTargetRect] = useState<DOMRect | null>(null);
    const [modalRect, setModalRect] = useState<DOMRect | null>(null);
    const modalRef = useRef<HTMLDivElement>(null);

    const currentStep = guideSteps[step];

    useLayoutEffect(() => {
        if (currentStep.type === 'highlight' && currentStep.targetId) {
            const elem = document.getElementById(currentStep.targetId);
            if (elem) {
                const rect = elem.getBoundingClientRect();
                setTargetRect(rect);
                elem.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
            }
        } else {
            setTargetRect(null);
        }

        if (modalRef.current) {
            setModalRect(modalRef.current.getBoundingClientRect());
        }
    }, [step, currentStep]);

    const nextStep = () => (step < guideSteps.length - 1) ? setStep(s => s + 1) : onComplete();
    const prevStep = () => (step > 0) ? setStep(s => s - 1) : undefined;

    const renderHighlight = () => {
        if (!targetRect) return null;
        const style = {
            left: `${targetRect.left}px`,
            top: `${targetRect.top}px`,
            width: `${targetRect.width}px`,
            height: `${targetRect.height}px`,
            boxShadow: `0 0 0 9999px rgba(0,0,0,0.7)`,
            borderRadius: '8px'
        };
        return (
            <>
                <div className="fixed pointer-events-none" style={style}></div>
                <div className="tour-highlight-animation" style={{...style, boxShadow: undefined, borderRadius: '8px'}}></div>
            </>
        )
    };
    
    const renderPointingLine = () => {
        if (!targetRect || !modalRect) return null;

        const modalCenterX = modalRect.left + modalRect.width / 2;
        const modalCenterY = modalRect.top + modalRect.height / 2;

        const targetCenterX = targetRect.left + targetRect.width / 2;
        const targetCenterY = targetRect.top + targetRect.height / 2;

        const angleRad = Math.atan2(targetCenterY - modalCenterY, targetCenterX - modalCenterX);
        
        // Find intersection with modal rectangle
        const startX = modalCenterX + (modalRect.width / 2) * Math.cos(angleRad) * 1.1;
        const startY = modalCenterY + (modalRect.height / 2) * Math.sin(angleRad) * 1.1;

        // Find intersection with target rectangle
        const endX = targetCenterX - (targetRect.width / 2) * Math.cos(angleRad) * 1.1;
        const endY = targetCenterY - (targetRect.height / 2) * Math.sin(angleRad) * 1.1;
        
        return (
            <svg className="fixed inset-0 w-full h-full pointer-events-none z-[102]">
                 <defs>
                    <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="0" refY="3.5" orient="auto">
                        <polygon points="0 0, 10 3.5, 0 7" fill="white" />
                    </marker>
                </defs>
                <line
                    x1={startX} y1={startY}
                    x2={endX} y2={endY}
                    stroke="white"
                    strokeWidth="2"
                    strokeDasharray="6, 6"
                    markerEnd="url(#arrowhead)"
                />
            </svg>
        );
    };

    return (
        <div className="fixed inset-0 z-[101] animate-fade-in" onClick={currentStep.type === 'highlight' ? nextStep : undefined}>
            {currentStep.type === 'highlight' && renderHighlight()}
            {currentStep.type === 'highlight' && renderPointingLine()}

            <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4">
                <div ref={modalRef} className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-md text-center transform transition-all animate-slide-in-up relative">
                    <div className="p-8 space-y-4">
                        <div className="mx-auto flex items-center justify-center h-20 w-20 rounded-full bg-gray-100 dark:bg-gray-700">{currentStep.icon}</div>
                        <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">{currentStep.title}</h2>
                        <p className="text-gray-600 dark:text-gray-300">{currentStep.content}</p>
                    </div>
                    <div className="px-6 py-4 bg-gray-50 dark:bg-gray-800/50 rounded-b-2xl">
                        <div className="flex justify-center mb-4 space-x-2">
                            {guideSteps.map((_, index) => <div key={index} className={`w-2.5 h-2.5 rounded-full transition-colors ${step === index ? 'bg-blue-500' : 'bg-gray-300 dark:bg-gray-600'}`}></div>)}
                        </div>
                        <div className="flex items-center justify-between">
                            <button onClick={prevStep} className={`px-4 py-2 text-sm font-semibold rounded-lg transition ${step === 0 ? 'opacity-0 cursor-default' : 'hover:bg-gray-200 dark:hover:bg-gray-700'}`} disabled={step === 0} aria-hidden={step === 0}>Anterior</button>
                            <button onClick={nextStep} className="px-6 py-2 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 transition-transform transform hover:scale-105">{step === guideSteps.length - 1 ? '¡Entendido!' : 'Siguiente'}</button>
                        </div>
                    </div>
                    <button onClick={onComplete} className="absolute top-3 right-3 p-2 rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"><CloseIcon className="w-5 h-5" /></button>
                </div>
            </div>
        </div>
    );
};

export default OnboardingGuide;