import React, { useState, useMemo } from 'react';
import { User, NotificationType, Game, StoreItem, AppSettings, AISystemSettings, Transaction, RequestStatus, TransactionType } from '../../types';
import { LogoutIcon, EnvelopeIcon, CheckCircleIcon, XCircleIcon, SparklesIcon, GamepadIcon, StoreIcon, RocketIcon, CoinIcon, CloseIcon, PencilIcon, TrashIcon, PlusCircleIcon, UserIcon } from '../../components/icons';
import Spinner from '../../components/Spinner';
import ConfirmationModal from '../../components/ConfirmationModal';
import * as api from '../../services/api';

// Child Views
import ManageUsersView from './ManageUsersView';

type AdminView = 'requests' | 'manage-users' | 'manage-games' | 'manage-store' | 'ai-systems';

const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
  });
};

const RequestTable: React.FC<{ requests: Transaction[]; onReview: (id: string, status: RequestStatus) => void; onImageView: (url: string) => void }> = ({ requests, onReview, onImageView }) => {
    const getStatusChip = (status: RequestStatus) => {
        const styles = {
            [RequestStatus.APPROVED]: "bg-green-200 text-green-800",
            [RequestStatus.REJECTED]: "bg-red-200 text-red-800",
            [RequestStatus.PENDING]: "bg-yellow-200 text-yellow-800",
        };
        return <span className={`px-2 py-1 text-xs font-medium rounded-full ${styles[status]}`}>{status}</span>;
    };
    
    const renderDetails = (req: Transaction) => {
        switch (req.type) {
            case TransactionType.PROMOTION:
                return <a href={req.details.postUrl} className="text-blue-500 hover:underline" target="_blank" rel="noopener noreferrer">View Post</a>;
            case TransactionType.PURCHASE:
                return <span>{req.details.amountGemas} GemasGo for ${req.details.amountUSD} {req.details.paymentProofUrl && <button onClick={() => onImageView(req.details.paymentProofUrl!)} className="ml-2 text-xs text-blue-400 hover:underline">(View Proof)</button>}</span>;
            case TransactionType.REDEMPTION:
                return <span>{req.details.diamondAmount} FF Diamonds for {req.details.gemasGoCost} GemasGo (ID: {req.details.ffUserId})</span>;
            default: return 'N/A';
        }
    };
    
    return (
      <div className="overflow-x-auto bg-gray-800/70 backdrop-blur-sm rounded-lg shadow-md">
        <table className="w-full text-sm text-left">
            <thead className="bg-gray-700/80 text-xs uppercase">
                <tr>
                    <th className="px-4 py-2">User</th><th className="px-4 py-2">Type</th><th className="px-4 py-2">Details</th><th className="px-4 py-2">Status</th><th className="px-4 py-2">AI Review</th><th className="px-4 py-2">Actions</th>
                </tr>
            </thead>
            <tbody>
                {requests.length === 0 ? (
                    <tr><td colSpan={6} className="text-center py-8 text-gray-400">No requests match the current filter.</td></tr>
                ) : (
                    requests.map(req => (
                        <tr key={req.id} className="border-b border-gray-700 text-sm">
                            <td className="px-4 py-3 font-medium">{req.userName}</td>
                            <td className="px-4 py-3">{req.type}</td>
                            <td className="px-4 py-3">{renderDetails(req)}</td>
                            <td className="px-4 py-3">{getStatusChip(req.status)}</td>
                            <td className="px-4 py-3 text-xs">{req.aiReview ? req.aiReview.status : 'N/A'}</td>
                            <td className="px-4 py-3">
                                {req.status === RequestStatus.PENDING && (
                                    <div className="flex space-x-2">
                                        <button onClick={() => onReview(req.id, RequestStatus.APPROVED)} title="Approve"><CheckCircleIcon className="w-6 h-6 text-green-500 hover:text-green-600"/></button>
                                        <button onClick={() => onReview(req.id, RequestStatus.REJECTED)} title="Reject"><XCircleIcon className="w-6 h-6 text-red-500 hover:text-red-600"/></button>
                                    </div>
                                )}
                            </td>
                        </tr>
                    ))
                )}
            </tbody>
        </table>
      </div>
    );
};

interface AdminDashboardProps {
  user: User;
  allUsers: User[];
  transactions: Transaction[];
  games: Game[];
  storeItems: StoreItem[];
  appSettings: AppSettings;
  aiSystemSettings: AISystemSettings;
  onLogout: () => void;
  onReviewRequest: (id: string, status: string, reason?: string) => void;
  onSendAdminMessage: (recipientId: string, text: string, photoUrl?: string) => void;
  onUpdateAISettings: (settings: AISystemSettings) => void;
  onSetGames: (games: Game[]) => void;
  onSetStoreItems: (items: StoreItem[]) => void;
  onSetAppSettings: (settings: AppSettings) => void;
  addNotification: (message: string, type: NotificationType) => void;
  onDataRefresh: () => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = (props) => {
    const { user, onLogout, transactions, games, storeItems, appSettings, aiSystemSettings, onUpdateAISettings, onSendAdminMessage, addNotification, onSetGames, onSetStoreItems, onSetAppSettings, onReviewRequest, onDataRefresh } = props;
    const [view, setView] = useState<AdminView>('requests');
    const [isImageModalOpen, setIsImageModalOpen] = useState<string | null>(null);
    const [isMessageModalOpen, setIsMessageModalOpen] = useState(false);
    const [rejectionInfo, setRejectionInfo] = useState<{ id: string, reason: string } | null>(null);
    
    const [recipient, setRecipient] = useState('');
    const [messageText, setMessageText] = useState('');
    const [messagePhoto, setMessagePhoto] = useState<File | null>(null);

    const [requestFilter, setRequestFilter] = useState<RequestStatus | 'ALL'>(RequestStatus.PENDING);
    
    const pendingCount = useMemo(() => transactions.filter(r => r.status === RequestStatus.PENDING).length, [transactions]);
    
    const filteredRequests = useMemo(() => {
        if (requestFilter === 'ALL') return transactions;
        return transactions.filter(r => r.status === requestFilter);
    }, [transactions, requestFilter]);

    const totalRevenue = useMemo(() => {
        return transactions
            .filter(t => t.type === TransactionType.PROMOTION && t.details.totalCost)
            .reduce((sum, promo) => sum + promo.details.totalCost!, 0);
    }, [transactions]);

    const handleReview = (id: string, status: RequestStatus) => {
        if (status === RequestStatus.REJECTED) {
            setRejectionInfo({ id, reason: '' });
        } else {
            onReviewRequest(id, status);
        }
    };

    const handleConfirmRejection = () => {
        if (rejectionInfo) {
            onReviewRequest(rejectionInfo.id, RequestStatus.REJECTED, rejectionInfo.reason);
            setRejectionInfo(null);
        }
    };
    
    const handleSendMessage = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!recipient || !messageText) {
            addNotification('Please select a user and write a message.', 'error');
            return;
        }
        let photoUrl: string | undefined;
        if (messagePhoto) {
            photoUrl = await fileToBase64(messagePhoto);
        }
        onSendAdminMessage(recipient, messageText, photoUrl);
        setIsMessageModalOpen(false);
        setMessageText('');
        setMessagePhoto(null);
    };

    const NavButton: React.FC<{ viewName: AdminView; icon: React.ReactElement<{ className?: string }>; label: string; }> = ({ viewName, icon, label }) => (
        <button onClick={() => setView(viewName)} aria-label={label} className={`flex flex-col items-center justify-center space-y-1 w-14 h-14 sm:w-16 rounded-lg transition-colors duration-200 has-tooltip ${view === viewName ? 'bg-purple-900/50 text-purple-400' : 'text-gray-400 hover:bg-gray-800/70'}`}>
            {React.cloneElement(icon, { className: "w-5 h-5 sm:w-6 sm:h-6" })}
            <span className="text-[10px] font-bold" aria-hidden="true">{label}</span>
            <div className="tooltip tooltip-bottom" role="tooltip">{label}</div>
        </button>
    );

    const renderView = () => {
        switch(view) {
            case 'requests': return (
                <div className="animate-fade-in">
                    <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
                        <h3 className="text-xl font-bold">Manage Requests</h3>
                        <div className="flex flex-wrap gap-2">
                            {(Object.values(RequestStatus).concat('ALL' as any)).map(status => (
                                <button key={status} onClick={() => setRequestFilter(status)} className={`px-3 py-1 text-sm font-semibold rounded-full transition ${requestFilter === status ? 'bg-blue-600 text-white' : 'bg-gray-700 hover:bg-gray-600'}`}>
                                    {status}
                                </button>
                            ))}
                        </div>
                    </div>
                    <RequestTable requests={filteredRequests} onReview={handleReview} onImageView={setIsImageModalOpen} />
                </div>
            );
            case 'manage-users': return <ManageUsersView users={props.allUsers} onDataRefresh={onDataRefresh} addNotification={addNotification} />;
            // Placeholder views for other sections
            default: return <div className="p-8 bg-gray-800/70 backdrop-blur-sm rounded-lg shadow-md"><p>This section is under construction.</p></div>;
        }
    }

    return (
        <div className="min-h-screen text-gray-200">
            {isImageModalOpen && (
                <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center" onClick={() => setIsImageModalOpen(null)}>
                    <img src={isImageModalOpen} alt="Proof" className="max-w-4xl max-h-[90vh] object-contain" />
                </div>
            )}
            {rejectionInfo && (
                <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center animate-fade-in">
                    <div className="bg-gray-800/80 backdrop-blur-sm p-6 rounded-lg w-full max-w-md m-4 animate-slide-in-up">
                        <h3 className="text-xl font-bold mb-4">Reason for Rejection</h3>
                        <textarea value={rejectionInfo.reason} onChange={e => setRejectionInfo(prev => prev ? { ...prev, reason: e.target.value } : null)} placeholder="Provide feedback... (Optional)" className="w-full p-2 bg-gray-700 rounded-md" rows={4} />
                        <div className="flex justify-end space-x-2 mt-4">
                            <button onClick={() => setRejectionInfo(null)} className="px-4 py-2 rounded-lg bg-gray-600">Cancel</button>
                            <button onClick={handleConfirmRejection} className="px-4 py-2 rounded-lg bg-red-600 text-white">Confirm Rejection</button>
                        </div>
                    </div>
                </div>
            )}
            {isMessageModalOpen && (
                 <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center">
                    <div className="bg-gray-800/80 backdrop-blur-sm p-6 rounded-lg w-full max-w-md">
                        <h3 className="text-xl font-bold mb-4">Send Message to User</h3>
                        <form onSubmit={handleSendMessage} className="space-y-4">
                            <select value={recipient} onChange={e => setRecipient(e.target.value)} className="w-full p-2 bg-gray-700 rounded-md">
                                <option value="">Select a user...</option>
                                {props.allUsers.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                            </select>
                            <textarea value={messageText} onChange={e => setMessageText(e.target.value)} placeholder="Your message..." className="w-full p-2 bg-gray-700 rounded-md" rows={4}></textarea>
                             <input type="file" accept="image/*" onChange={e => setMessagePhoto(e.target.files ? e.target.files[0] : null)} className="w-full text-sm file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-900/50 file:text-blue-300 hover:file:bg-blue-900" />
                            <div className="flex justify-end space-x-2">
                                <button type="button" onClick={() => setIsMessageModalOpen(false)} className="px-4 py-2 rounded-lg bg-gray-600">Cancel</button>
                                <button type="submit" className="px-4 py-2 rounded-lg bg-blue-600 text-white">Send</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            <header className="fixed top-0 left-0 right-0 bg-gray-800/80 backdrop-blur-sm shadow-md z-40">
                <div className="flex items-center justify-between h-14 px-4">
                    <div className="flex items-center space-x-2 bg-gray-700/70 px-2 py-1 rounded-full">
                        <CoinIcon className="w-4 h-4 text-green-400" />
                        <span className="font-semibold text-sm text-green-400">{totalRevenue.toFixed(2)}</span>
                        <span className="text-xs text-gray-400">Revenue</span>
                    </div>
                    <div className="flex items-center space-x-2">
                        <span className="font-semibold text-sm hidden sm:inline">Welcome, {user.name}</span>
                        <button onClick={onLogout} className="p-1.5 rounded-full hover:bg-gray-700/70"><LogoutIcon className="w-5 h-5 text-red-500" /></button>
                    </div>
                </div>
                <nav className="h-16 flex justify-center items-center border-t border-gray-700">
                    <div className="flex space-x-2">
                        <NavButton viewName="requests" icon={<RocketIcon />} label={`Requests (${pendingCount})`} />
                        <NavButton viewName="manage-users" icon={<UserIcon />} label="Users" />
                        <NavButton viewName="manage-games" icon={<GamepadIcon />} label="Games" />
                        <NavButton viewName="manage-store" icon={<StoreIcon />} label="Store" />
                        <button onClick={() => setIsMessageModalOpen(true)} aria-label="Send Message" className="flex flex-col items-center justify-center space-y-1 w-14 h-14 sm:w-16 rounded-lg transition-colors duration-200 has-tooltip text-gray-400 hover:bg-gray-800/70">
                            <EnvelopeIcon className="w-5 h-5 sm:w-6 sm:h-6" />
                            <span className="text-[10px] font-bold" aria-hidden="true">Message</span>
                            <div className="tooltip tooltip-bottom" role="tooltip">Send Message</div>
                        </button>
                        <NavButton viewName="ai-systems" icon={<SparklesIcon />} label="AI Systems" />
                    </div>
                </nav>
            </header>

            <main className="flex-1 p-4 pt-32">{renderView()}</main>
        </div>
    );
};

export default AdminDashboard;
