import React, { useState } from 'react';
import { User, NotificationType, UserRole } from '../../types';
import { PencilIcon, TrashIcon, CoinIcon, HeartIcon } from '../../components/icons';
import ConfirmationModal from '../../components/ConfirmationModal';
import UserEditModal from './UserEditModal';
import * as api from '../../services/api';

interface ManageUsersViewProps {
    users: User[];
    onDataRefresh: () => void;
    addNotification: (msg: string, type: NotificationType) => void;
}

const ManageUsersView: React.FC<ManageUsersViewProps> = ({ users, onDataRefresh, addNotification }) => {
    const [editingUser, setEditingUser] = useState<User | null>(null);
    const [deletingUser, setDeletingUser] = useState<User | null>(null);

    const handleSaveUser = async (userId: string, updates: Partial<User>) => {
        try {
            // Separate role update from other updates
            const { role, ...otherUpdates } = updates;

            const promises = [];

            if (Object.keys(otherUpdates).length > 0) {
                promises.push(api.updateUserByAdmin(userId, otherUpdates));
            }
            if (role) {
                promises.push(api.updateUserRole(userId, role as UserRole));
            }

            await Promise.all(promises);
            
            addNotification(`User details updated successfully!`, 'success');
            onDataRefresh();
        } catch (error) {
            addNotification(error.message, 'error');
        } finally {
            setEditingUser(null);
        }
    };

    const handleDeleteUser = async () => {
        if (!deletingUser) return;
        try {
            await api.deleteUserByAdmin(deletingUser.id);
            addNotification(`User "${deletingUser.name}" has been deleted.`, 'success');
            onDataRefresh();
        } catch (error) {
             addNotification(error.message, 'error');
        } finally {
            setDeletingUser(null);
        }
    };
    
    const getRoleChip = (role: UserRole) => {
        return role === 'ADMIN' 
            ? <span className="px-2 py-0.5 text-[10px] font-medium rounded-full bg-purple-200 text-purple-800">Admin</span>
            : <span className="px-2 py-0.5 text-[10px] font-medium rounded-full bg-gray-200 text-gray-800">User</span>;
    }


    return (
        <div className="animate-fade-in">
            {editingUser && (
                <UserEditModal
                    user={editingUser}
                    onSave={handleSaveUser}
                    onClose={() => setEditingUser(null)}
                />
            )}
            {deletingUser && (
                <ConfirmationModal
                    isOpen={!!deletingUser}
                    onClose={() => setDeletingUser(null)}
                    onConfirm={handleDeleteUser}
                    title="Delete User"
                    confirmText="Delete"
                >
                   <p>Are you sure you want to delete the user "<strong>{deletingUser.name}</strong>"? This will permanently remove them and all their associated data (promotions, requests, etc.) from the platform and cannot be undone.</p> 
                </ConfirmationModal>
            )}
            <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold">Manage Users</h3>
            </div>
            <div className="overflow-x-auto bg-gray-800/70 backdrop-blur-sm rounded-lg shadow-md">
                <table className="w-full text-sm text-left">
                    <thead className="bg-gray-700/80 text-xs uppercase">
                        <tr>
                            <th className="px-4 py-2">Name</th>
                            <th className="px-4 py-2">Role</th>
                            <th className="px-4 py-2">GemasGo</th>
                            <th className="px-4 py-2">Lives</th>
                            <th className="px-4 py-2">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {users.map(user => (
                            <tr key={user.id} className="border-b border-gray-700">
                                <td className="px-4 py-3 font-medium text-sm">{user.name}</td>
                                <td className="px-4 py-3">{getRoleChip(user.role)}</td>
                                <td className="px-4 py-3 text-sm">
                                    <div className="flex items-center space-x-1">
                                        <CoinIcon className="w-4 h-4 text-yellow-500" />
                                        <span>{user.gemasGo.toFixed(2)}</span>
                                    </div>
                                </td>
                                <td className="px-4 py-3 text-sm">
                                    <div className="flex items-center space-x-1">
                                        <HeartIcon className="w-4 h-4 text-red-500" />
                                        <span>{user.lives}</span>
                                    </div>
                                </td>
                                <td className="px-4 py-3 flex space-x-3">
                                    <button onClick={() => setEditingUser(user)} title="Edit User">
                                        <PencilIcon className="w-5 h-5 text-yellow-500 hover:text-yellow-600"/>
                                    </button>
                                    {/* Prevent deleting the main admin or self */}
                                     {user.name !== 'admin' && user.id !== (window as any).currentUser?.id && (
                                        <button onClick={() => setDeletingUser(user)} title="Delete User">
                                            <TrashIcon className="w-5 h-5 text-red-500 hover:text-red-600"/>
                                        </button>
                                    )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                 {users.length === 0 && (
                    <div className="text-center py-8 text-gray-400">No users found.</div>
                )}
            </div>
        </div>
    );
};

export default ManageUsersView;