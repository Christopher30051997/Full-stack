import React, { useState } from 'react';
import { User, UserRole } from '../../types';
import Spinner from '../../components/Spinner';

interface UserEditModalProps {
    user: User;
    onSave: (userId: string, updates: Partial<User>) => void;
    onClose: () => void;
}

const UserEditModal: React.FC<UserEditModalProps> = ({ user, onSave, onClose }) => {
    const [gemasGo, setGemasGo] = useState(user.gemasGo);
    const [lives, setLives] = useState(user.lives);
    const [role, setRole] = useState(user.role);
    const [isSaving, setIsSaving] = useState(false);

    const handleSave = async () => {
        setIsSaving(true);
        // This function now passes all changed fields back to the parent
        onSave(user.id, { 
            gemasGo: Number(gemasGo), 
            lives: Number(lives),
            role: role
        });
        // Parent will handle closing the modal after API call
    };

    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center animate-fade-in" onClick={onClose}>
            <div className="bg-gray-800/80 backdrop-blur-sm p-4 rounded-lg w-full max-w-md m-4" onClick={e => e.stopPropagation()}>
                <h3 className="text-xl font-bold mb-4">Edit User: {user.name}</h3>
                <div className="space-y-4">
                    <div>
                        <label htmlFor="gemasGo" className="block text-sm font-medium text-gray-300">GemasGo</label>
                        <input
                            id="gemasGo"
                            type="number"
                            value={gemasGo}
                            onChange={(e) => setGemasGo(parseFloat(e.target.value))}
                            className="w-full p-2 bg-gray-700 rounded-md mt-1"
                        />
                    </div>
                    <div>
                        <label htmlFor="lives" className="block text-sm font-medium text-gray-300">Lives</label>
                        <input
                            id="lives"
                            type="number"
                            value={lives}
                            onChange={(e) => setLives(parseInt(e.target.value, 10))}
                            className="w-full p-2 bg-gray-700 rounded-md mt-1"
                        />
                    </div>
                     <div>
                        <label htmlFor="role" className="block text-sm font-medium text-gray-300">Role</label>
                        <select
                            id="role"
                            value={role}
                            onChange={(e) => setRole(e.target.value as UserRole)}
                            className="w-full p-2 bg-gray-700 rounded-md mt-1"
                            disabled={user.name === 'admin'} // Prevent changing the main admin's role
                        >
                            <option value={UserRole.USER}>User</option>
                            <option value={UserRole.ADMIN}>Admin</option>
                        </select>
                    </div>
                </div>
                <div className="flex justify-end space-x-2 mt-6">
                    <button onClick={onClose} className="px-4 py-2 rounded-lg bg-gray-600 hover:bg-gray-500" disabled={isSaving}>
                        Cancel
                    </button>
                    <button onClick={handleSave} className="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 w-24" disabled={isSaving}>
                        {isSaving ? <Spinner /> : 'Save'}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default UserEditModal;