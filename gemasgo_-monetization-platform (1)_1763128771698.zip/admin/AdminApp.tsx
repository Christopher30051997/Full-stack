import React, { useState, useEffect, useCallback } from 'react';
import LandingPage from '../pages/LandingPage';
import AdminDashboard from './pages/AdminDashboard';
import { User, UserRole, Transaction, AppNotification, NotificationType, Game, StoreItem, AppSettings, AISystemSettings } from '../types';
import Notification from '../components/Notification';
import Spinner from '../components/Spinner';
import * as api from '../services/api';

const AdminApp: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [adminData, setAdminData] = useState<any | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);

  const addNotification = useCallback((message: string, type: NotificationType) => {
    const newNotification: AppNotification = { id: Date.now(), message, type };
    setNotifications(prev => [...prev, newNotification]);
  }, []);

  const fetchAdminData = useCallback(async () => {
    setIsLoading(true);
    try {
      const data = await api.getAdminData();
      setAdminData(data);
    } catch (error) {
      addNotification(error.message, 'error');
      handleLogout();
    } finally {
      setIsLoading(false);
    }
  }, [addNotification]);
  
  const checkAdminSession = useCallback(async () => {
    const token = localStorage.getItem('gemasgo-adm-token');
    if (token) {
      try {
        const user = await api.getMe(); 
        if (user.role === UserRole.ADMIN) {
            setCurrentUser(user);
            await fetchAdminData();
        } else {
            handleLogout();
        }
      } catch (error) {
        handleLogout();
      }
    } else {
        setIsLoading(false);
    }
  }, [fetchAdminData]);

  useEffect(() => {
    document.documentElement.className = 'dark';
    checkAdminSession();
  }, [checkAdminSession]);

  const dismissNotification = (id: number) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const handleLogin = async (user: User, isRegister: boolean, password?: string) => {
    try {
        const { token, ...loggedInUser } = await api.login(user.name, password || '', false);
        if (loggedInUser.role === UserRole.ADMIN) {
            localStorage.setItem('gemasgo-adm-token', token);
            setCurrentUser(loggedInUser);
            await fetchAdminData();
            addNotification(`Welcome, ${loggedInUser.name}!`, 'success');
        } else {
            addNotification('Access denied. Not an administrator.', 'error');
        }
    } catch(error) {
         addNotification(error.message, 'error');
    }
  };

  const handleLogout = () => {
    api.logout();
    setCurrentUser(null);
    setAdminData(null);
    addNotification('You have been logged out.', 'info');
  };
  
  const handleReviewRequest = async (requestId: string, newStatus: string, reason?: string) => {
    try {
        await api.reviewRequest(requestId, newStatus, reason);
        await fetchAdminData();
        addNotification('Request status updated!', 'success');
    } catch (error) {
        addNotification(error.message, 'error');
    }
  };
  
  const handleSendAdminMessage = async (recipientId: string, text: string, photoUrl?: string) => {
    try {
        await api.sendAdminMessage(recipientId, text, photoUrl);
        addNotification('Message sent successfully!', 'success');
        await fetchAdminData();
    } catch (error) {
        addNotification(error.message, 'error');
    }
  };

  const handleSetGames = async (games: Game[]) => {
      // This is a simplified handler. In a real app, you'd make specific API calls for add/update/delete.
      // For now, we'll just refetch.
      await fetchAdminData();
  }

   const handleSetStoreItems = async (items: StoreItem[]) => {
      await fetchAdminData();
  }

  const onSetAppSettings = async (settings: AppSettings) => {
      try {
        await api.updateAppSettings(settings);
        addNotification('App settings updated!', 'success');
        await fetchAdminData();
      } catch (error) {
          addNotification(error.message, 'error');
      }
  };

  const onUpdateAISettings = async (settings: AISystemSettings) => {
     try {
        await api.updateAiSettings(settings);
        addNotification('AI settings updated!', 'success');
        await fetchAdminData();
      } catch (error) {
          addNotification(error.message, 'error');
      }
  };
  
  const onForceDataRefresh = () => {
      fetchAdminData();
  }

  const renderContent = () => {
     if (isLoading) {
        return <div className="min-h-screen flex items-center justify-center"><Spinner size="w-12 h-12" /></div>;
    }
    if (!currentUser) {
        return <LandingPage onLogin={handleLogin} isAdminLogin={true} />;
    }
    if (!adminData) {
        return <div className="min-h-screen flex items-center justify-center"><p>Error loading admin data. Please try again.</p></div>;
    }
    
    return (
        <AdminDashboard
            user={currentUser}
            allUsers={adminData.users}
            transactions={adminData.transactions}
            games={adminData.games}
            storeItems={adminData.storeItems}
            appSettings={adminData.appSettings}
            aiSystemSettings={adminData.aiSystemSettings}
            onLogout={handleLogout}
            onReviewRequest={handleReviewRequest}
            onSendAdminMessage={handleSendAdminMessage}
            onUpdateAISettings={onUpdateAISettings}
            onSetGames={handleSetGames}
            onSetStoreItems={handleSetStoreItems}
            onSetAppSettings={onSetAppSettings}
            addNotification={addNotification}
            onDataRefresh={onForceDataRefresh}
        />
    );
  };
  
  return (
    <div className="app-container min-h-screen font-sans bg-transparent">
      <div className="fixed top-5 left-1/2 -translate-x-1/2 z-[100] space-y-2">
        {notifications.map(n => (
          <Notification key={n.id} message={n.message} type={n.type} onClose={() => dismissNotification(n.id)} />
        ))}
      </div>
      {renderContent()}
    </div>
  );
};

export default AdminApp;
