import React, { useState, useEffect, useCallback } from 'react';
import LandingPage from './pages/LandingPage';
import Dashboard from './pages/Dashboard';
// FIX: Added AppState to imports and defined specific data types for creation handlers.
import { User, Game, Promotion, AppNotification, NotificationType, PurchaseRequest, DiamondRedemption, AdminMessage, AppSettings, AppState, UserRole } from './types';
import Notification from './components/Notification';
import Spinner from './components/Spinner';
import * as api from './services/api';

// --- Local types for creation payloads to match server expectations ---
type NewPromotionData = Omit<Promotion['details'], 'totalCost'> & { totalCost: number };
type NewPurchaseRequestData = Omit<PurchaseRequest['details'], 'paymentProofUrl'>;
type NewDiamondRedemptionData = DiamondRedemption['details'];


// --- APP COMPONENT ---
const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  // FIX: Used the newly defined AppState type.
  const [appData, setAppData] = useState<AppState | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  let notificationIdCounter = 0;

  const addNotification = useCallback((message: string, type: NotificationType) => {
    const newNotification: AppNotification = { id: Date.now(), message, type };
    setNotifications(prev => [...prev, newNotification]);
  }, []);

  const fetchInitialData = useCallback(async () => {
    try {
      const data = await api.getInitialAppData();
      setAppData({
        games: data.games,
        promotions: data.promotions,
        adminMessages: data.adminMessages,
        appSettings: data.appSettings,
      });
    } catch (error) {
      addNotification(error.message, 'error');
    }
  }, [addNotification]);
  
  const checkUserSession = useCallback(async () => {
    setIsLoading(true);
    const token = localStorage.getItem('gemasgo-token');
    if (token) {
      try {
        const user = await api.getMe();
        setCurrentUser(user);
        await fetchInitialData();
      } catch (error) {
        localStorage.removeItem('gemasgo-token');
        setCurrentUser(null);
        addNotification('Your session has expired. Please log in again.', 'info');
      }
    }
    setIsLoading(false);
  }, [addNotification, fetchInitialData]);

  useEffect(() => {
    checkUserSession();
    document.documentElement.className = 'dark';
  }, [checkUserSession]);

  const dismissNotification = (id: number) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };
  
  const handleLogin = async (user: User, isRegister: boolean, password?: string) => {
    try {
        // FIX: The api.login function now returns the token, which needs to be stored.
        // Also, destructure the response to get the user object for setting state.
        const { token, ...loggedInUser } = await api.login(user.name, password || '', isRegister, user.email);
        localStorage.setItem('gemasgo-token', token);
        setCurrentUser(loggedInUser);
        await fetchInitialData();
        addNotification(`Welcome, ${loggedInUser.name}!`, 'success');
    } catch (error) {
        addNotification(error.message, 'error');
    }
  };

  const handleLogout = () => {
    api.logout();
    setCurrentUser(null);
    setAppData(null);
    addNotification('You have been logged out.', 'info');
  };
  
  const updateUser = async (userId: string, updates: Partial<User>) => {
    try {
        const updatedUser = await api.updateUser(userId, updates);
        setCurrentUser(updatedUser);
        return updatedUser;
    } catch (error) {
        addNotification(error.message, 'error');
        throw error;
    }
  };
  
  const handleToggleFavoriteGame = async (gameId: string) => {
    if (!currentUser) return;
    try {
        const updatedUser = await api.toggleFavoriteGame(gameId);
        setCurrentUser(updatedUser);
        const isFavorite = updatedUser.favoriteGameIds.includes(gameId);
        addNotification(isFavorite ? 'Game added to favorites!' : 'Game removed from favorites.', 'info');
    } catch(error) {
        addNotification(error.message, 'error');
    }
  };

  const handleOnboardingComplete = async (userId: string) => {
    await updateUser(userId, { isNewUser: false });
  };

  // FIX: Updated signature to use a specific data type for new promotions.
  const handleNewPromotion = async (promoData: NewPromotionData) => {
    if (!currentUser) return;
    try {
        const newPromotion = await api.createPromotion(promoData);
        if (appData) {
            setAppData(prev => prev ? ({...prev, promotions: [...prev.promotions, newPromotion]}) : null);
        }
        // The cost is deducted on the backend, so we need to refresh the user
        const updatedUser = await api.getMe();
        setCurrentUser(updatedUser);
        addNotification('Promotion submitted for review!', 'success');
    } catch (error) {
        addNotification(error.message, 'error');
    }
  };

  // FIX: Updated signature to use a specific data type for new purchase requests.
  const handleNewPurchaseRequest = async (requestData: NewPurchaseRequestData, proofKey: string): Promise<boolean> => {
      if (!currentUser) return false;
      try {
        await api.createPurchaseRequest(requestData, proofKey);
        addNotification('Purchase request sent for verification.', 'success');
        return true;
      } catch (error) {
        addNotification(error.message, 'error');
        return false;
      }
  };

  // FIX: Updated signature to use a specific data type for new diamond redemptions.
  const handleNewDiamondRedemption = async (requestData: NewDiamondRedemptionData) => {
      if (!currentUser) return;
      try {
          await api.createDiamondRedemption(requestData);
           // The cost is deducted on the backend, so we need to refresh the user
          const updatedUser = await api.getMe();
          setCurrentUser(updatedUser);
          addNotification('Diamond redemption request sent for processing.', 'success');
      } catch (error) {
          addNotification(error.message, 'error');
      }
  };
  
  const handleMarkMessagesAsRead = async () => {
    if (!currentUser || !appData) return;
      try {
        await api.markMessagesAsRead();
        setAppData(prev => prev ? ({ ...prev, adminMessages: prev.adminMessages.map(m => ({ ...m, read: true })) }) : null);
      } catch (error) {
         addNotification(error.message, 'error');
      }
  };
  

  // --- RENDER LOGIC ---
  const renderContent = () => {
    if (isLoading) {
      return (
        <div className="min-h-screen flex items-center justify-center">
          <Spinner size="w-12 h-12" />
        </div>
      );
    }

    if (!currentUser || !appData) {
      return <LandingPage onLogin={handleLogin} isAdminLogin={false} />;
    }
    
    return (
      <Dashboard
        user={currentUser}
        onLogout={handleLogout}
        games={appData.games.filter(g => g.isActive)}
        appSettings={appData.appSettings!}
        promotions={appData.promotions}
        adminMessages={appData.adminMessages}
        onNewPromotion={handleNewPromotion}
        onNewPurchaseRequest={handleNewPurchaseRequest}
        onNewDiamondRedemption={handleNewDiamondRedemption}
        onMarkMessagesAsRead={handleMarkMessagesAsRead}
        onToggleFavoriteGame={handleToggleFavoriteGame}
        onOnboardingComplete={() => handleOnboardingComplete(currentUser.id)}
        addNotification={addNotification}
        onUpdateUser={updateUser}
      />
    );
  };
  
  return (
    <div className="app-container min-h-screen font-sans bg-transparent">
      <div className="fixed top-5 left-1/2 -translate-x-1/2 z-[100] space-y-2">
        {notifications.map(n => (
          <Notification 
            key={n.id}
            message={n.message}
            type={n.type}
            onClose={() => dismissNotification(n.id)}
          />
        ))}
      </div>
      {renderContent()}
    </div>
  );
};

export default App;