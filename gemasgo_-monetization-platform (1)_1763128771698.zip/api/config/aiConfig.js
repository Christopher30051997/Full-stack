module.exports = {
  rewardPercentage: 20,
  adminPercentage: 80,
};
