const Game = require("../models/Game");
const handleApiError = require('../utils/errorHandler');

// @desc    Obtener todos los juegos activos
// @route   GET /api/games
// @access  Public
exports.getAllGames = async (req, res) => {
  try {
    const games = await Game.find({ isActive: true });
    res.status(200).json(games);
  } catch (err) {
    handleApiError(err, res);
  }
};
