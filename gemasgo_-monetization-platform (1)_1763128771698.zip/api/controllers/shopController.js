const ShopItem = require("../models/ShopItem");

exports.getShopItems = async (req, res) => {
  // Lógica para obtener los artículos de la tienda
  res.send("Get shop items");
};

exports.purchaseItem = async (req, res) => {
  // Lógica para manejar la compra de un artículo
  res.send("Item purchased");
};
