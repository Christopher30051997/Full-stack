const User = require("../models/User");

// Ejemplo de una función del controlador de usuario
exports.updateUserProfile = async (req, res) => {
  // Lógica para actualizar el perfil del usuario
  res.send("User profile updated");
};
