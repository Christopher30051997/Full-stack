const User = require("../models/User");
const jwt = require("jsonwebtoken");
const handleApiError = require('../utils/errorHandler');
const ErrorResponse = require("../utils/errorResponse");

const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: "30d",
  });
};

// Helper function to generate and send token
const sendTokenResponse = (user, statusCode, res) => {
  const token = generateToken(user._id);
  const userObject = user.toObject();
  delete userObject.password;

  res.status(statusCode).json({
    ...userObject,
    token,
  });
};

// @desc    Registrar un nuevo usuario
// @route   POST /api/auth/register
// @access  Public
exports.register = async (req, res) => {
  try {
    const { name, email, password } = req.body;

    if (!name || !password) {
      throw new ErrorResponse("Please provide name and password", 400);
    }

    // SECURITY FIX: Prevent registration of 'admin' username
    if (name.toLowerCase() === 'admin') {
      throw new ErrorResponse("This username is reserved.", 400);
    }
    
    const userExists = await User.findOne({ name });
    if (userExists) {
        throw new ErrorResponse("User with that name already exists", 400);
    }

    const user = await User.create({ name, email, password });
    sendTokenResponse(user, 201, res);
  } catch (err) {
    handleApiError(err, res);
  }
};

// @desc    Autenticar un usuario o crearlo si no existe
// @route   POST /api/auth/login
// @access  Public
exports.login = async (req, res) => {
  try {
    const { name, password, email } = req.body;

    if (!name || !password) {
       throw new ErrorResponse("Please provide name and password", 400);
    }

    const user = await User.findOne({ name }).select('+password');
    
    // If the user does not exist, create a new account
    if (!user) {
      // SECURITY CHECK: Prevent non-admins from registering as admin via login
      if (name.toLowerCase() === 'admin') {
         throw new ErrorResponse("Invalid credentials", 401);
      }
      const newUser = await User.create({ name, password, email });
      return sendTokenResponse(newUser, 201, res);
    }

    // If user exists, check password
    const isMatch = await user.matchPassword(password);
    if (!isMatch) {
      throw new ErrorResponse("Invalid credentials", 401);
    }

    sendTokenResponse(user, 200, res);
  } catch (err) {
    handleApiError(err, res);
  }
};

// @desc    Obtener datos del usuario logueado
// @route   GET /api/auth/me
// @access  Private
exports.getMe = async (req, res) => {
    try {
        const appSettings = await require('../models/Setting').getSettings('appSettings');
        // Ensure lives are up-to-date before sending
        await req.user.regenerateLives(appSettings);
        // req.user is established by the middleware 'protect'
        res.status(200).json(req.user);
    } catch (err) {
        handleApiError(err, res);
    }
};