const User = require("../models/User");
const Game = require("../models/Game");
const ShopItem = require("../models/ShopItem");
const Setting = require("../models/Setting");
const Promotion = require("../models/Promotion");
const PurchaseRequest = require("../models/PurchaseRequest");
const DiamondRedemption = require("../models/DiamondRedemption");
const AdminMessage = require("../models/AdminMessage");
const handleApiError = require('../utils/errorHandler');

const defaultAppSettings = {
    livesCost: 0.08,
    cryptoAddress: "YOUR_CRYPTO_WALLET_ADDRESS_HERE",
    cryptoCurrency: "USDT",
    lifeRegenEnabled: true,
    lifeRegenMinutes: 5,
};

const defaultAiSettings = {
    adRevenueSplit: { isActive: true, userPercentage: 50 },
    antiFraud: { isActive: true, enablePromotionValidation: true, sensitivity: 'medium', ipWhitelist: [] },
    notificationSystem: { isActive: true, proactive: true },
    supervisorSystem: { isActive: true, monitoringLevel: 'basic' },
    transactionMonitoring: { isActive: true, riskThresholds: { purchase: 75, redemption: 75 }, autoBlock: false }
};

// @desc    Obtener todos los datos para el panel de admin
// @route   GET /api/admin/data
// @access  Private/Admin
exports.getAdminData = async (req, res) => {
    try {
        const [
            users,
            promotions,
            purchaseRequests,
            diamondRedemptions,
            games,
            storeItems,
            appSettings,
            aiSystemSettings
        ] = await Promise.all([
            User.find({}).select("-password"), // Fetch all users for role management
            Promotion.find({}).sort({ createdAt: -1 }),
            PurchaseRequest.find({}).sort({ createdAt: -1 }),
            DiamondRedemption.find({}).sort({ createdAt: -1 }),
            Game.find({}).sort({ name: 1 }),
            ShopItem.find({}).sort({ name: 1 }),
            Setting.getSettings('appSettings', defaultAppSettings),
            Setting.getSettings('aiSystemSettings', defaultAiSettings)
        ]);
        res.status(200).json({
            users, promotions, purchaseRequests, diamondRedemptions, games, storeItems, appSettings, aiSystemSettings
        });
    } catch (err) {
        handleApiError(err, res);
    }
};

// @desc    Revisar una solicitud (Promoción, Compra, Canje)
// @route   PUT /api/admin/requests/:id/review
// @access  Private/Admin
exports.reviewRequest = async (req, res) => {
    try {
        const { id } = req.params;
        const { status, reason } = req.body;

        const request = 
            await Promotion.findById(id) ||
            await PurchaseRequest.findById(id) ||
            await DiamondRedemption.findById(id);

        if (!request) {
            return res.status(404).json({ message: "Request not found" });
        }

        request.status = status;
        
        // Handle logic for different statuses
        if (status === 'APPROVED') {
            if (request.constructor.modelName === 'PurchaseRequest') {
                const user = await User.findById(request.userId);
                if(user) {
                    user.gemasGo += request.amountGemas;
                    await user.save();
                    await AdminMessage.create({
                        recipientId: user._id,
                        text: `Your purchase of ${request.amountGemas} GemasGo has been approved and credited to your account.`,
                    });
                }
            }
        } else if (status === 'REJECTED') {
            const user = await User.findById(request.userId);
            if (user) {
                 // Return funds if a promotion or redemption was rejected
                if (request.constructor.modelName === 'Promotion' || request.constructor.modelName === 'DiamondRedemption') {
                    // Use the correct cost field for each type
                    const costToRefund = request.totalCost || request.gemasGoCost;
                    if (costToRefund) {
                        user.gemasGo += costToRefund;
                        await user.save();
                    }
                }
                 // Notify user of rejection for ALL types
                const typeName = request.constructor.modelName === 'PurchaseRequest' ? 'purchase'
                               : request.constructor.modelName === 'DiamondRedemption' ? 'redemption'
                               : 'promotion';

                await AdminMessage.create({
                    recipientId: user._id,
                    text: `Your ${typeName} request was rejected. ${reason ? `Reason: ${reason}` : 'No reason was provided.'}`,
                });
            }
        }

        await request.save();
        res.status(200).json(request);
    } catch (err)
 {
        handleApiError(err, res);
    }
};


// @desc    Enviar mensaje de admin a un usuario
// @route   POST /api/admin/messages
// @access  Private/Admin
exports.sendAdminMessage = async (req, res) => {
    try {
        const { recipientId, text, photoUrl } = req.body;
        const message = await AdminMessage.create({ recipientId, text, photoUrl });
        res.status(201).json(message);
    } catch (err) {
        handleApiError(err, res);
    }
};

// @desc    Actualizar AppSettings
// @route   PUT /api/admin/settings/app
// @access  Private/Admin
exports.updateAppSettings = async (req, res) => {
    try {
        const settings = await Setting.findOneAndUpdate({ key: 'appSettings' }, { value: req.body }, { new: true, upsert: true });
        res.status(200).json(settings.value);
    } catch (err) {
        handleApiError(err, res);
    }
};

// @desc    Actualizar AISystemSettings
// @route   PUT /api/admin/settings/ai
// @access  Private/Admin
exports.updateAiSettings = async (req, res) => {
    try {
        const settings = await Setting.findOneAndUpdate({ key: 'aiSystemSettings' }, { value: req.body }, { new: true, upsert: true });
        res.status(200).json(settings.value);
    } catch (err) {
        handleApiError(err, res);
    }
};

// --- Game Management ---
exports.createGame = async (req, res) => {
    try {
        const game = await Game.create(req.body);
        res.status(201).json(game);
    } catch(err) { handleApiError(err, res); }
};
exports.updateGame = async (req, res) => {
    try {
        const game = await Game.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
        if (!game) return res.status(404).json({ message: "Game not found" });
        res.status(200).json(game);
    } catch(err) { handleApiError(err, res); }
};
exports.deleteGame = async (req, res) => {
    try {
        const game = await Game.findByIdAndDelete(req.params.id);
        if (!game) return res.status(404).json({ message: "Game not found" });
        res.status(200).json({ success: true });
    } catch(err) { handleApiError(err, res); }
};


// --- Store Item Management ---
exports.createStoreItem = async (req, res) => {
    try {
        const item = await ShopItem.create(req.body);
        res.status(201).json(item);
    } catch(err) { handleApiError(err, res); }
};
exports.updateStoreItem = async (req, res) => {
    try {
        const item = await ShopItem.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
        if (!item) return res.status(404).json({ message: "Store item not found" });
        res.status(200).json(item);
    } catch(err) { handleApiError(err, res); }
};
exports.deleteStoreItem = async (req, res) => {
    try {
        const item = await ShopItem.findByIdAndDelete(req.params.id);
        if (!item) return res.status(404).json({ message: "Store item not found" });
        res.status(200).json({ success: true });
    } catch(err) { handleApiError(err, res); }
};

// --- User Management ---
exports.updateUserByAdmin = async (req, res) => {
    try {
        const user = await User.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
        if (!user) return res.status(404).json({ message: "User not found" });
        res.status(200).json(user);
    } catch(err) { handleApiError(err, res); }
};
exports.deleteUserByAdmin = async (req, res) => {
     try {
        const user = await User.findByIdAndDelete(req.params.id);
        if (!user) return res.status(404).json({ message: "User not found" });
        
        // DATA INTEGRITY: Delete associated data
        await Promotion.deleteMany({ userId: req.params.id });
        await PurchaseRequest.deleteMany({ userId: req.params.id });
        await DiamondRedemption.deleteMany({ userId: req.params.id });
        await AdminMessage.deleteMany({ recipientId: req.params.id });

        res.status(200).json({ success: true });
    } catch(err) { handleApiError(err, res); }
};
exports.getAllUsers = async (req, res) => {
  try {
    const users = await User.find({}).select("-password");
    res.status(200).json(users);
  } catch (err) {
    handleApiError(err, res);
  }
};
exports.updateUserRole = async (req, res) => {
    try {
        const { role } = req.body;
        const user = await User.findById(req.params.id);
        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }
        user.role = role;
        await user.save();
        res.status(200).json(user);
    } catch(err) {
        handleApiError(err, res);
    }
};