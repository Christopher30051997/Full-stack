const User = require("../models/User");
const Game = require("../models/Game");
const Promotion = require("../models/Promotion");
const PurchaseRequest = require("../models/PurchaseRequest");
const DiamondRedemption = require("../models/DiamondRedemption");
const AdminMessage = require("../models/AdminMessage");
const Setting = require("../models/Setting");
const SubmittedProof = require("../models/SubmittedProof");
const handleApiError = require('../utils/errorHandler');
const ErrorResponse = require("../utils/errorResponse");

const defaultAppSettings = {
    livesCost: 0.08,
    cryptoAddress: "YOUR_CRYPTO_WALLET_ADDRESS_HERE",
    cryptoCurrency: "USDT",
    lifeRegenEnabled: true,
    lifeRegenMinutes: 5,
};

exports.getInitialData = async (req, res) => {
    try {
        const userId = req.user._id;

        const appSettings = await Setting.getSettings('appSettings', defaultAppSettings);
        // Securely regenerate lives on the backend before sending user data
        await req.user.regenerateLives(appSettings);

        const [games, promotions, adminMessages] = await Promise.all([
            Game.find({ isActive: true }),
            Promotion.find({ status: 'APPROVED' }).sort({ createdAt: -1 }).limit(20),
            AdminMessage.find({ recipientId: userId }).sort({ createdAt: -1 }),
        ]);

        res.status(200).json({ games, promotions, adminMessages, appSettings });
    } catch (err) {
        handleApiError(err, res);
    }
};

exports.updateUser = async (req, res) => {
    try {
        const { lives, gemasGo, gameProgress, isNewUser } = req.body;
        const user = await User.findById(req.user.id);
        if (!user) throw new ErrorResponse("User not found", 404);

        const oldLives = user.lives;

        if (lives !== undefined) user.lives = lives;
        if (gemasGo !== undefined) user.gemasGo = gemasGo;
        if (gameProgress !== undefined) user.gameProgress = gameProgress;
        if (isNewUser !== undefined) user.isNewUser = isNewUser;

        // If lives are spent, update the regen timestamp
        if (lives !== undefined && lives < oldLives) {
            user.lastLifeRegenTimestamp = Date.now();
        }

        await user.save();
        res.status(200).json(user);
    } catch (err) {
        handleApiError(err, res);
    }
};

exports.toggleFavoriteGame = async (req, res) => {
    try {
        const { gameId } = req.params;
        const user = await User.findById(req.user.id);
        if (!user) throw new ErrorResponse("User not found", 404);

        const index = user.favoriteGameIds.indexOf(gameId);
        if (index > -1) {
            user.favoriteGameIds.splice(index, 1);
        } else {
            user.favoriteGameIds.push(gameId);
        }
        await user.save();
        res.status(200).json(user);
    } catch (err) {
        handleApiError(err, res);
    }
};

exports.createPromotion = async (req, res) => {
    try {
        const user = req.user;
        const { totalCost } = req.body;
        if (user.gemasGo < totalCost) {
            throw new ErrorResponse("Insufficient GemasGo", 400);
        }

        const promotion = await Promotion.create({
            ...req.body,
            userId: user._id,
            userName: user.name
        });

        user.gemasGo -= totalCost;
        await user.save();

        res.status(201).json(promotion);
    } catch (err) {
        handleApiError(err, res);
    }
};

exports.createPurchaseRequest = async (req, res) => {
    try {
        const { proofKey, ...requestData } = req.body;

        const existingProof = await SubmittedProof.findOne({ key: proofKey });
        if (existingProof) {
            throw new ErrorResponse("This payment proof has already been submitted.", 400);
        }

        const request = await PurchaseRequest.create({
            ...requestData,
            userId: req.user._id,
            userName: req.user.name,
        });

        await SubmittedProof.create({ key: proofKey });

        res.status(201).json(request);
    } catch (err) {
        handleApiError(err, res);
    }
};

exports.createDiamondRedemption = async (req, res) => {
    try {
        const user = req.user;
        const { gemasGoCost } = req.body;

        if (user.gemasGo < gemasGoCost) {
             throw new ErrorResponse("Insufficient GemasGo", 400);
        }
        const redemption = await DiamondRedemption.create({
            ...req.body,
            userId: user._id,
            userName: user.name,
        });

        user.gemasGo -= gemasGoCost;
        await user.save();
        
        res.status(201).json(redemption);
    } catch (err) {
        handleApiError(err, res);
    }
};

exports.markMessagesAsRead = async (req, res) => {
    try {
        await AdminMessage.updateMany({ recipientId: req.user._id, read: false }, { read: true });
        res.status(200).json({ success: true });
    } catch (err) {
        handleApiError(err, res);
    }
};

// @desc    Obtener el historial de promociones del usuario
// @route   GET /api/app/promotions/history
// @access  Private
exports.getPromotionHistory = async (req, res) => {
    try {
        const promotions = await Promotion.find({ userId: req.user._id }).sort({ createdAt: -1 });
        res.status(200).json(promotions);
    } catch (err) {
        handleApiError(err, res);
    }
};