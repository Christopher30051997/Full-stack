const express = require("express");
const router = express.Router();
// const { getAds, recordAdView } = require("../controllers/adController");
// const { protect } = require("../middleware/authMiddleware");

// router.get("/", protect, getAds);
// router.post("/view", protect, recordAdView);

module.exports = router;
