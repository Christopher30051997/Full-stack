const express = require("express");
const router = express.Router();
const { getAllGames } = require("../controllers/gameController");

// @route   GET api/games
// @desc    Obtener todos los juegos activos
// @access  Public
router.get("/", getAllGames);

module.exports = router;
