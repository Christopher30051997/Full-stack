const express = require("express");
const router = express.Router();
const { 
    getInitialData,
    toggleFavoriteGame,
    updateUser,
    createPromotion,
    createPurchaseRequest,
    createDiamondRedemption,
    markMessagesAsRead,
    getPromotionHistory
} = require("../controllers/appController");
const { protect } = require('../middleware/authMiddleware');


router.get("/data", protect, getInitialData);
router.put("/user", protect, updateUser);
router.put("/user/toggle-favorite/:gameId", protect, toggleFavoriteGame);
router.get("/promotions/history", protect, getPromotionHistory);
router.post("/promotions", protect, createPromotion);
router.post("/purchase-requests", protect, createPurchaseRequest);
router.post("/diamond-redemptions", protect, createDiamondRedemption);
router.post("/messages/read", protect, markMessagesAsRead);


module.exports = router;