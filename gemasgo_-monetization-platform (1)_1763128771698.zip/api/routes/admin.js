const express = require("express");
const router = express.Router();
const { 
    getAdminData,
    reviewRequest,
    sendAdminMessage,
    updateAppSettings,
    updateAiSettings,
    createGame,
    updateGame,
    deleteGame,
    createStoreItem,
    updateStoreItem,
    deleteStoreItem,
    updateUserByAdmin,
    deleteUserByAdmin,
    getAllUsers,
    updateUserRole
} = require("../controllers/adminController");
const { protect, admin } = require("../middleware/authMiddleware");

// All routes in this file are protected and for admins only
router.use(protect, admin);

// Dashboard Data
router.get("/data", getAdminData);

// Requests
router.put("/requests/:id/review", reviewRequest);

// Messages
router.post("/messages", sendAdminMessage);

// Settings
router.put("/settings/app", updateAppSettings);
router.put("/settings/ai", updateAiSettings);

// Game Management
router.route("/games")
    .post(createGame);
router.route("/games/:id")
    .put(updateGame)
    .delete(deleteGame);

// Store Management
router.route("/store-items")
    .post(createStoreItem);
router.route("/store-items/:id")
    .put(updateStoreItem)
    .delete(deleteStoreItem);

// User Management
router.get("/users", getAllUsers);
router.route("/users/:id")
    .put(updateUserByAdmin)
    .delete(deleteUserByAdmin);
router.put("/users/:id/role", updateUserRole);


module.exports = router;