const ErrorResponse = require('./errorResponse');

const errorHandler = (err, res) => {
    let error = { ...err };
    error.message = err.message;
    
    // Log for dev
    console.error('API ERROR:', err);

    // Mongoose bad ObjectId
    if (err.name === 'CastError') {
        const message = `Resource not found`;
        error = new ErrorResponse(message, 404);
    }

    // Mongoose duplicate key
    if (err.code === 11000) {
        const message = 'A user with that value already exists. Please choose another.';
        error = new ErrorResponse(message, 400);
    }

    // Mongoose validation error
    if (err.name === 'ValidationError') {
        const message = Object.values(err.errors).map(val => val.message).join(', ');
        error = new ErrorResponse(message, 400);
    }

    if (res.headersSent) {
      return;
    }

    res.status(error.statusCode || 500).json({
        message: error.message || 'A server error occurred. Please try again later.'
    });
};

module.exports = errorHandler;