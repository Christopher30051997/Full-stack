const mongoose = require("mongoose");

const SettingSchema = new mongoose.Schema({
    key: { type: String, required: true, unique: true },
    value: { type: mongoose.Schema.Types.Mixed, required: true }
});

// Method to get or create settings
SettingSchema.statics.getSettings = async function(key, defaultValue) {
    let setting = await this.findOne({ key });
    if (!setting) {
        setting = await this.create({ key, value: defaultValue });
    }
    return setting.value;
};

module.exports = mongoose.model("Setting", SettingSchema);