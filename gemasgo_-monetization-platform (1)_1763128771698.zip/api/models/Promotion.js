const mongoose = require("mongoose");

const PromotionSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    userName: { type: String, required: true },
    socialMedia: { type: String, enum: ['Facebook', 'YouTube', 'TikTok'], required: true },
    postUrl: { type: String, required: true },
    duration: { type: Number, required: true },
    views: { type: Number, required: true },
    likes: { type: Number, required: true },
    comments: { type: Number, required: true },
    totalCost: { type: Number, required: true },
    status: { type: String, enum: ['PENDING', 'APPROVED', 'REJECTED'], default: 'PENDING' },
    aiReview: {
        status: { type: String, enum: ['Pending', 'Approved', 'Flagged'], default: 'Pending' },
        reason: { type: String, default: '' }
    }
}, { 
    timestamps: true,
    toJSON: {
        virtuals: true,
        transform(doc, ret) {
            ret.id = ret._id;
            delete ret._id;
            delete ret.__v;
        }
    },
    toObject: {
        virtuals: true,
        transform(doc, ret) {
            ret.id = ret._id;
            delete ret._id;
            delete ret.__v;
        }
    }
});

module.exports = mongoose.model("Promotion", PromotionSchema);