const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

const UserSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, "Please add a name"],
    unique: true,
    trim: true,
    maxlength: [7, "Name cannot be more than 7 characters"],
  },
  email: {
    type: String,
    required: false,
    unique: true,
    sparse: true, // Allows multiple documents to have a null value for email
    trim: true,
    match: [
      /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/,
      "Please add a valid email",
    ],
  },
  password: {
    type: String,
    required: [true, "Please add a password"],
    minlength: 6,
    select: false, // Don't return password by default
  },
  role: {
    type: String,
    enum: ['USER', 'ADMIN'],
    default: 'USER',
  },
  gemasGo: {
    type: Number,
    default: 0,
  },
  lives: {
    type: Number,
    default: 5,
  },
  favoriteGameIds: {
    type: [String],
    default: [],
  },
  isNewUser: {
    type: Boolean,
    default: true,
  },
  gameProgress: {
    type: mongoose.Schema.Types.Mixed,
    default: {}
  },
  lastLifeRegenTimestamp: {
    type: Number
  }
}, {
    timestamps: true,
    toJSON: {
        virtuals: true,
        transform(doc, ret) {
            ret.id = ret._id;
            delete ret._id;
            delete ret.__v;
        }
    },
    toObject: {
        virtuals: true,
        transform(doc, ret) {
            ret.id = ret._id;
            delete ret._id;
            delete ret.__v;
        }
    }
});

// Encriptar contraseña antes de guardar
UserSchema.pre('save', async function (next) {
  if (!this.isModified('password')) {
    return next();
  }
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

// Método para comparar contraseñas
UserSchema.methods.matchPassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

// Método para regenerar vidas
UserSchema.methods.regenerateLives = async function (appSettings) {
  if (this.lives >= 5 || !appSettings.lifeRegenEnabled) {
    return;
  }
  const now = Date.now();
  const lastRegen = this.lastLifeRegenTimestamp || now;
  const elapsedMs = now - lastRegen;
  const regenIntervalMs = appSettings.lifeRegenMinutes * 60 * 1000;
  
  if (elapsedMs >= regenIntervalMs) {
    const livesToRegen = Math.floor(elapsedMs / regenIntervalMs);
    const newLives = Math.min(5, this.lives + livesToRegen);
    if (newLives > this.lives) {
        this.lives = newLives;
        this.lastLifeRegenTimestamp = now;
        await this.save();
    }
  }
};


module.exports = mongoose.model("User", UserSchema);