// Nota: La diferenciación de Admin se maneja a través del campo 'role' en el modelo User.
// Este archivo se mantiene para consistencia con la estructura solicitada.
// Podría usarse en el futuro para perfiles de administrador más complejos.
module.exports = {};
