const mongoose = require("mongoose");

const PurchaseRequestSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    userName: { type: String, required: true },
    amountGemas: { type: Number, required: true },
    amountUSD: { type: Number, required: true },
    paymentProofUrl: { type: String }, // Storing as base64 data URL
    status: { type: String, enum: ['PENDING', 'APPROVED', 'REJECTED'], default: 'PENDING' }
}, { 
    timestamps: true,
    toJSON: {
        virtuals: true,
        transform(doc, ret) {
            ret.id = ret._id;
            delete ret._id;
            delete ret.__v;
            ret.type = 'Purchase';
        }
    },
    toObject: {
        virtuals: true,
        transform(doc, ret) {
            ret.id = ret._id;
            delete ret._id;
            delete ret.__v;
            ret.type = 'Purchase';
        }
    }
});

module.exports = mongoose.model("PurchaseRequest", PurchaseRequestSchema);