const mongoose = require("mongoose");

const AdminMessageSchema = new mongoose.Schema({
    recipientId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    text: { type: String, required: true, maxLength: 500 },
    photoUrl: { type: String }, // Can be a data URL or a link to stored image
    read: { type: Boolean, default: false }
}, { 
    timestamps: true,
    toJSON: {
        virtuals: true,
        transform(doc, ret) {
            ret.id = ret._id;
            delete ret._id;
            delete ret.__v;
        }
    },
    toObject: {
        virtuals: true,
        transform(doc, ret) {
            ret.id = ret._id;
            delete ret._id;
            delete ret.__v;
        }
    }
});

module.exports = mongoose.model("AdminMessage", AdminMessageSchema);