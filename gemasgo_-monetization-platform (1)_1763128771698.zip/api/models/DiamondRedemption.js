const mongoose = require("mongoose");

const DiamondRedemptionSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    userName: { type: String, required: true },
    diamondAmount: { type: Number, enum: [100, 465], required: true },
    gemasGoCost: { type: Number, required: true },
    ffUserId: { type: String, required: true },
    status: { type: String, enum: ['PENDING', 'APPROVED', 'REJECTED'], default: 'PENDING' }
}, { 
    timestamps: true,
    toJSON: {
        virtuals: true,
        transform(doc, ret) {
            ret.id = ret._id;
            delete ret._id;
            delete ret.__v;
            ret.type = 'Redemption';
        }
    },
    toObject: {
        virtuals: true,
        transform(doc, ret) {
            ret.id = ret._id;
            delete ret._id;
            delete ret.__v;
            ret.type = 'Redemption';
        }
    }
});

module.exports = mongoose.model("DiamondRedemption", DiamondRedemptionSchema);